import { render } from "preact";
import { useEffect, useState, useCallback, useRef } from "preact/hooks";
import { html, Icone, Avatar, semente, COLECOES } from "./nucleo.js";
import { Painel } from "./telas/painel.js";
import { Funis } from "./telas/funis.js";
import { Conversas } from "./telas/conversas.js";
import { Configuracoes } from "./telas/configuracoes.js";
import { EmBreve } from "./telas/embreve.js";
import { CodigoMfa, TelaAtivarObrigatorio } from "./telas/seguranca.js";

const cfg = window.VEKA || {};
const configurado = String(cfg.SUPABASE_URL || "").startsWith("http");
const sb = configurado ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;

const MENU = [
  { grupo: "Vender" },
  { r: "painel", nome: "Painel", ic: "painel" },
  { r: "funis", nome: "Funis", ic: "funis" },
  { r: "conversas", nome: "Conversas", ic: "conversas" },
  { r: "atividades", nome: "Atividades", ic: "atividades" },
  { r: "metas", nome: "Gestor de metas", ic: "metas" },
  { grupo: "Preparar" },
  { r: "prospeccao", nome: "Prospecção", ic: "prospeccao" },
  { r: "disparos", nome: "Disparos", ic: "disparos" },
  { r: "produtos", nome: "Produtos", ic: "produtos" },
  { r: "scripts", nome: "Scripts e playbook", ic: "scripts" },
  { r: "contatos", nome: "Contatos", ic: "contatos" },
  { grupo: "Conta" },
  { r: "config", nome: "Configurações", ic: "config" },
];

const vazio = () => { const s = { config: null }; COLECOES.forEach((c) => (s[c] = [])); return s; };
const rotaAtual = () => (location.hash.replace(/^#\/?/, "") || "painel").split("?")[0];

function Login({ aviso }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState(aviso || "");
  const [ocupado, setOcupado] = useState(false);
  const [modo, setModo] = useState("entrar");
  const enviar = async (e) => {
    e.preventDefault();
    if (!sb) return;
    setErro(""); setOcupado(true);
    if (modo === "esqueci") {
      const { error } = await sb.auth.resetPasswordForEmail(email.trim(), { redirectTo: location.origin + location.pathname + "#/config" });
      setOcupado(false);
      setErro(error ? "Não foi possível enviar o e-mail agora." : "");
      if (!error) setModo("enviado");
      return;
    }
    const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password: senha });
    setOcupado(false);
    if (error) setErro("E-mail ou senha não conferem.");
  };
  return html`
    <div class="login">
      <div class="lado">
        <div class="marca"><img src="veka.png" alt="" /><div><b>Veka</b><span>Comercial</span></div></div>
        <div><h2>Alinhados à sua empresa, conectados ao seu público.</h2><p>Funil, conversas e metas do comercial da Veka num lugar só.</p></div>
        <small style="color:#7f93b3">Agência Veka · Saquarema</small>
      </div>
      <div class="form-lado">
        <form onSubmit=${enviar} novalidate>
          <h1>${modo === "entrar" ? "Entrar" : "Recuperar a senha"}</h1>
          ${!configurado && html`<p class="erro">Falta configurar a URL e a chave do Supabase no começo do index.html.</p>`}
          ${modo === "enviado" ? html`<p class="okmsg">Se esse e-mail tem acesso, o link para criar uma senha nova chegou na caixa de entrada.</p>` : html`
            <label class="campo">E-mail<input class="inp" type="email" autocomplete="username" value=${email} onInput=${(e) => setEmail(e.target.value)} required /></label>
            ${modo === "entrar" && html`<label class="campo">Senha<input class="inp" type="password" autocomplete="current-password" value=${senha} onInput=${(e) => setSenha(e.target.value)} required /></label>`}
            ${erro && html`<p class="erro" role="alert">${erro}</p>`}
            <button class="btn prim" type="submit" disabled=${ocupado || !configurado}>${modo === "entrar" ? "Entrar" : "Mandar link por e-mail"}</button>`}
          <button type="button" class="btn" onClick=${() => { setModo(modo === "entrar" ? "esqueci" : "entrar"); setErro(""); }}>${modo === "entrar" ? "Esqueci a senha" : "Voltar para o login"}</button>
        </form>
      </div>
    </div>`;
}

function App() {
  const [sessao, setSessao] = useState(undefined);
  const [eu, setEu] = useState(null);
  const [equipe, setEquipe] = useState([]);
  const [s, setS] = useState(vazio());
  const [pronto, setPronto] = useState(false);
  const [aviso, setAviso] = useState("");
  const [rota, setRota] = useState(rotaAtual());
  const [toast, setToast] = useState("");
  const [mfa, setMfa] = useState("");
  const [tem2fa, setTem2fa] = useState(true);
  const tToast = useRef(null);
  const ultimoUso = useRef(Date.now());

  const avisar = useCallback((t) => { setToast(t); clearTimeout(tToast.current); tToast.current = setTimeout(() => setToast(""), 3200); }, []);

  useEffect(() => {
    const f = () => setRota(rotaAtual());
    addEventListener("hashchange", f);
    return () => removeEventListener("hashchange", f);
  }, []);

  useEffect(() => {
    if (!sb) { setSessao(null); return; }
    sb.auth.getSession().then(({ data }) => setSessao(data.session));
    const { data } = sb.auth.onAuthStateChange((_ev, ses) => setSessao(ses));
    return () => data.subscription.unsubscribe();
  }, []);

  const carregarEquipe = useCallback(async () => {
    const { data } = await sb.from("equipe").select("*").order("nome");
    setEquipe(data || []);
    return data || [];
  }, []);

  const carregar = useCallback(async () => {
    const todos = [];
    for (let de = 0; ; de += 1000) {
      const { data, error } = await sb.from("itens").select("colecao, id, dados").range(de, de + 999);
      if (error) throw error;
      todos.push(...(data || []));
      if (!data || data.length < 1000) break;
    }
    if (!todos.some((r) => r.colecao === "config")) {
      const sem = semente();
      const linhas = [{ colecao: "config", id: "geral", dados: sem.config }];
      Object.keys(sem).filter((k) => k !== "config").forEach((c) => sem[c].forEach((it) => linhas.push({ colecao: c, id: it.id, dados: it })));
      const { error } = await sb.from("itens").upsert(linhas);
      if (error) throw error;
      todos.push(...linhas);
    }
    const novo = vazio();
    todos.forEach((r) => { if (r.colecao === "config") novo.config = r.dados; else if (novo[r.colecao]) novo[r.colecao].push(r.dados); });
    setS(novo);
  }, []);

  useEffect(() => {
    if (!sessao) { setEu(null); setPronto(false); return; }
    let canal;
    (async () => {
      setAviso("");
      // Segurança: quem tem verificação em duas etapas precisa digitar o código antes de qualquer dado.
      const { data: nivel } = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
      if (nivel && nivel.nextLevel === "aal2" && nivel.currentLevel !== "aal2") { setMfa("codigo"); return; }
      setMfa("ok");
      const { data: fat } = await sb.auth.mfa.listFactors();
      setTem2fa((fat?.totp || []).length > 0);
      const lista = await carregarEquipe();
      const meu = lista.find((p) => p.user_id === sessao.user.id);
      if (!meu || !meu.ativo) {
        setAviso("Seu acesso entrou, mas ainda não está liberado na equipe do comercial. Fale com a Ana.");
        await sb.auth.signOut();
        return;
      }
      setEu(meu);
      try { await carregar(); } catch (e) { avisar("Não consegui carregar os dados: " + (e.message || e)); }
      setPronto(true);
      canal = sb.channel("sistema")
        .on("postgres_changes", { event: "*", schema: "public", table: "itens" }, (p) => {
          setS((atual) => {
            const r = p.eventType === "DELETE" ? p.old : p.new;
            if (!r) return atual;
            if (r.colecao === "config") return p.eventType === "DELETE" ? atual : { ...atual, config: r.dados };
            if (!atual[r.colecao]) return atual;
            const lista = atual[r.colecao].filter((x) => x.id !== r.id);
            return { ...atual, [r.colecao]: p.eventType === "DELETE" ? lista : [...lista, r.dados] };
          });
        })
        .on("postgres_changes", { event: "*", schema: "public", table: "equipe" }, () => carregarEquipe().then((l) => setEu((e) => l.find((x) => x.user_id === e?.user_id) || e)))
        .subscribe();
    })();
    return () => { if (canal) sb.removeChannel(canal); };
  }, [sessao]);

  // Segurança: sai sozinho depois de um tempo sem uso.
  const minutos = s.config?.seguranca?.inatividade || 30;
  useEffect(() => {
    if (!eu) return;
    const marcar = () => { ultimoUso.current = Date.now(); };
    const evs = ["pointerdown", "keydown", "scroll", "touchstart", "mousemove"];
    evs.forEach((e) => addEventListener(e, marcar, { passive: true }));
    const t = setInterval(async () => {
      if (Date.now() - ultimoUso.current > minutos * 60000) {
        setAviso("Você saiu sozinho depois de " + minutos + " minutos sem usar o sistema. Entre de novo.");
        await sb.auth.signOut();
      }
    }, 20000);
    return () => { evs.forEach((e) => removeEventListener(e, marcar)); clearInterval(t); };
  }, [eu?.user_id, minutos]);

  // Gravação: atualiza a tela na hora e manda para o banco.
  const salvar = useCallback(async (colecao, itens) => {
    const lista = Array.isArray(itens) ? itens : [itens];
    setS((atual) => {
      if (colecao === "config") return { ...atual, config: lista[0] };
      const ids = new Set(lista.map((x) => x.id));
      return { ...atual, [colecao]: [...atual[colecao].filter((x) => !ids.has(x.id)), ...lista] };
    });
    const { error } = await sb.from("itens").upsert(lista.map((it) => ({ colecao, id: it.id, dados: it })));
    if (error) avisar("Não salvou: " + error.message);
    return !error;
  }, [avisar]);
  const apagar = useCallback(async (colecao, ids) => {
    const lista = Array.isArray(ids) ? ids : [ids];
    if (!lista.length) return;
    if (!eu?.admin) { avisar("Só administradores apagam dados."); return; }
    setS((atual) => ({ ...atual, [colecao]: atual[colecao].filter((x) => !lista.includes(x.id)) }));
    const { error } = await sb.from("itens").delete().eq("colecao", colecao).in("id", lista);
    if (error) avisar("Não apagou: " + error.message);
  }, [avisar, eu?.admin]);

  if (sessao === undefined) return html`<p style="padding:40px;color:#667085">Carregando…</p>`;
  if (sessao && mfa === "codigo") return html`<${CodigoMfa} sb=${sb} />`;
  if (sessao && !eu && !aviso) return html`<p style="padding:40px;color:#667085">Entrando…</p>`;
  if (!sessao || !eu) return html`<${Login} aviso=${aviso} />`;
  if (pronto && s.config?.seguranca?.exigir2fa && !tem2fa) return html`<${TelaAtivarObrigatorio} sb=${sb} pronto=${() => { setTem2fa(true); avisar("Verificação ativada. Bem-vinda de volta!"); }} />`;

  const ctx = { sb, s, eu, equipe, salvar, apagar, avisar, recarregarEquipe: carregarEquipe, setEu };
  const telas = { painel: Painel, funis: Funis, conversas: Conversas, config: Configuracoes };
  const Tela = telas[rota] || EmBreve;
  const item = MENU.find((m) => m.r === rota);

  return html`
    <div class="shell">
      <aside class="menu" aria-label="Menu">
        <a class="marca" href="#/painel"><img src="veka.png" alt="" /><div><b>Veka</b><span>Comercial</span></div></a>
        <nav>
          ${MENU.map((m) => m.grupo ? html`<span class="grupo">${m.grupo}</span>` : html`
            <a class="item" href=${"#/" + m.r} aria-current=${rota === m.r ? "page" : undefined}><${Icone} n=${m.ic} t=${19} />${m.nome}</a>`)}
        </nav>
        <a class="rodape" href="#/config" style="text-decoration:none">
          <${Avatar} pessoa=${eu} />
          <div><div class="nome">${eu.nome}</div><div class="papel">${eu.cargo || eu.papel}</div></div>
        </a>
      </aside>
      <main class="conteudo">
        ${pronto ? html`<${Tela} ctx=${ctx} rota=${rota} nome=${item?.nome || "Painel"} />` : html`<p class="dica">Carregando os dados do comercial…</p>`}
      </main>
      ${toast && html`<div class="toast" role="status">${toast}</div>`}
    </div>`;
}

render(html`<${App} />`, document.getElementById("app"));

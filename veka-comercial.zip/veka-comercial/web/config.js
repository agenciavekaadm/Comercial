// ⚙️ Preencha com os dados do projeto (Supabase > Project Settings > API Keys).
// A chave pública pode ficar aqui: quem protege os dados são as regras do banco.
// Nunca coloque aqui a chave secreta (service_role / Secret key).
window.VEKA = {
  SUPABASE_URL: "COLE_AQUI_A_URL_DO_PROJETO",
  SUPABASE_ANON_KEY: "COLE_AQUI_A_CHAVE_PUBLICA"
};

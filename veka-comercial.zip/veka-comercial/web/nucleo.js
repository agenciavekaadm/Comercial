// Peças compartilhadas por todas as telas.
import { h } from "preact";
import htm from "htm";

export const html = htm.bind(h);

export const ETAPAS = ["Solicitações recebidas", "Abordado", "Respondeu", "Follow-up 1", "Follow-up 2", "Follow-up 3", "Convertido", "Perdido"];
export const TIPOS = ["Mensagem", "Ligar", "Reunião", "Proposta", "Tarefa"];
export const COR_ETAPA = { "Solicitações recebidas": "#7048c8", "Abordado": "#2b5fb8", "Respondeu": "#3f8cfe", "Follow-up 1": "#b45f0e", "Follow-up 2": "#b45f0e", "Follow-up 3": "#b45f0e", "Convertido": "#14804a", "Perdido": "#c2334d" };

const p2 = (n) => String(n).padStart(2, "0");
export const iso = (d = new Date()) => d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate());
export const hoje = () => iso(new Date());
export const emDias = (n) => { const d = new Date(); d.setDate(d.getDate() + (Number(n) || 0)); return iso(d); };
export const br = (s) => { if (!s) return ""; const p = String(s).slice(0, 10).split("-"); return p[2] + "/" + p[1]; };
export const brl = (n) => "R$ " + Math.round(Number(n) || 0).toLocaleString("pt-BR");
export const pct = (a, b) => (b ? Math.round((a / b) * 100) + "%" : "0%");
export const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
export const digitos = (v) => String(v || "").replace(/\D/g, "");
export const iniciais = (nome) => String(nome || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase();
export const diasDesde = (d) => { if (!d) return ""; const n = Math.max(0, Math.round((new Date(hoje()) - new Date(String(d).slice(0, 10))) / 86400000)); return n === 0 ? "hoje" : n === 1 ? "há 1 dia" : "há " + n + " dias"; };

// Ícones de traço, no mesmo desenho do protótipo.
const P = {
  painel: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  funis: '<rect x="3" y="4" width="5" height="16" rx="1.5"/><rect x="10" y="4" width="5" height="11" rx="1.5"/><rect x="17" y="4" width="4" height="7" rx="1.5"/>',
  conversas: '<path d="M4 5h16v11H9l-5 4z"/>',
  atividades: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  metas: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>',
  prospeccao: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  disparos: '<path d="M21 3 3 10.5l7 2.5 2.5 7z"/><path d="M21 3 10 13"/>',
  produtos: '<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/>',
  scripts: '<path d="M6 3h9l4 4v14H6z"/><path d="M9 11h7M9 15h7M9 7h4"/>',
  contatos: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.8c2 .7 3.2 2.5 3.5 5.2"/>',
  config: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  mais: '<path d="M12 5v14M5 12h14"/>',
  esq: '<path d="M15 6l-6 6 6 6"/>',
  dir: '<path d="M9 6l6 6-6 6"/>',
  fechar: '<path d="M6 6l12 12M18 6 6 18"/>',
  baixar: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  sair: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
};
export const Icone = ({ n, t = 20, cor = "currentColor", e = 1.8 }) =>
  html`<svg aria-hidden="true" width=${t} height=${t} viewBox="0 0 24 24" fill="none" stroke=${cor} stroke-width=${e} stroke-linecap="round" stroke-linejoin="round" dangerouslySetInnerHTML=${{ __html: P[n] || "" }}></svg>`;

export const Modal = ({ titulo, larga, fechar, children }) => html`
  <div class="fundo" onClick=${(e) => { if (e.target === e.currentTarget) fechar(); }}>
    <div class=${"modal" + (larga ? " larga" : "")} role="dialog" aria-modal="true" aria-label=${titulo}>
      <div class="modal-topo"><h2>${titulo}</h2><button type="button" class="x" aria-label="Fechar" onClick=${fechar}><${Icone} n="fechar" t=${14} e=${2.4} /></button></div>
      ${children}
    </div>
  </div>`;

export const Avatar = ({ pessoa, grande }) => html`
  <span class=${"av" + (grande ? " g" : "")}>${pessoa?.foto_url ? html`<img src=${pessoa.foto_url} alt="" />` : iniciais(pessoa?.nome)}</span>`;

export function csvHref(linhas) {
  const esc = (v) => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
  return "data:text/csv;charset=utf-8," + encodeURIComponent("﻿" + linhas.map((r) => r.map(esc).join(";")).join("\n"));
}

// Move um lead de etapa e roda as automações do funil. Devolve as mudanças a gravar.
export function moverLead(s, lead, etapa, quem) {
  const dia = hoje();
  let novo = { ...lead, stage: etapa, mudou: dia, ganho: etapa === "Convertido" ? dia : lead.ganho, hist: [{ t: dia, text: "Moveu para " + etapa + (quem ? " · " + quem : "") }, ...(lead.hist || [])] };
  const tarefas = [];
  for (const a of s.automacoes.filter((x) => x.funil === lead.funil && x.stage === etapa)) {
    if (a.acao === "atividade") tarefas.push({ id: uid("t"), leadId: lead.id, title: (a.titulo || a.tipo) + " · " + lead.name, tipo: a.tipo, date: emDias(a.dias), hora: "", done: false, resp: novo.resp });
    if (a.acao === "cadencia") { const c = s.cadencias.find((x) => x.id === a.cadId); (c?.passos || []).forEach((p) => tarefas.push({ id: uid("t"), leadId: lead.id, title: p.title + " · " + lead.name, tipo: p.canal, date: emDias(p.dias), hora: "", done: false, resp: novo.resp })); }
    if (a.acao === "resp") novo = { ...novo, resp: a.resp };
    if (a.acao === "mover" && a.dest) novo = { ...novo, funil: a.dest };
  }
  return { lead: novo, tarefas };
}

// Conteúdo inicial do sistema, gravado no banco no primeiro acesso.
export function semente() {
  const L = (id, name, funil, stage, origem, servico, valor, criado, extra = {}) => ({ id, name, insta: "", whats: "", funil, stage, origem, servico, valor, criado, mudou: criado, obs: "", resp: "Carol", perda: "", ganho: "", hist: [], ...extra });
  return {
    config: {
      id: "geral",
      origens: ["Tráfego pago", "Instagram", "Indicação", "WhatsApp", "Novo seguidor", "Evento", "Outro"],
      motivos: ["Preço", "Parou de responder", "Fechou com outra agência", "Não é o momento", "Sem verba para tráfego"],
      metasAtiv: { abordagens: 83, respostas: 0, conversoes: 3 },
      playbook: "Quem faz o quê: a Carol (SDR) qualifica os leads e faz o social selling, da abordagem até o lead aceitar a call. O Victor (closer) faz as calls de venda e fecha o contrato.\n\nSolicitações recebidas: aprove ou recuse em até 1 dia útil.\n\nAbordado: mande a primeira mensagem do banco de scripts no mesmo dia.\n\nRespondeu: convide para a call com o Victor.\n\nFollow-up 1, 2 e 3: siga a cadência padrão (2, 5 e 10 dias). Depois do terceiro sem resposta, mova para Perdido.\n\nConvertido: lance a venda no Gestor de metas e crie o cliente no Sistema Veka.",
    },
    funis: [{ id: "entrada", name: "Entrada", ordem: 1 }, { id: "social", name: "Social Selling", ordem: 2 }],
    leads: [
      L("l1", "Leva Pizza", "entrada", "Abordado", "Tráfego pago", "Gestão de redes sociais", 1800, "2026-11-10"),
      L("l2", "Academia Maia", "entrada", "Abordado", "WhatsApp", "", 0, "2026-11-11"),
      L("l3", "Na Onda Bistrô", "social", "Respondeu", "Instagram", "Gestão de redes sociais", 1800, "2026-11-04"),
      L("l4", "Agência de turismo (Raphael)", "social", "Respondeu", "Indicação", "Gestão de redes sociais", 1800, "2026-11-05"),
      L("l5", "Padaria Lagomar", "social", "Follow-up 1", "Instagram", "Gestão de redes sociais", 1800, "2026-10-28"),
      L("l6", "Space Sushi", "social", "Follow-up 2", "Instagram", "Gestão de redes sociais", 1800, "2026-10-22"),
      L("l7", "Juliana Coach", "social", "Abordado", "Instagram", "Gestão de redes sociais", 1800, "2026-11-09"),
      L("l8", "Nu Pote", "social", "Convertido", "Indicação", "Produção audiovisual", 0, "2026-09-20", { ganho: "2026-09-24", resp: "Victor" }),
      L("l9", "Casa Sabor do Crepe", "social", "Convertido", "Indicação", "Produção audiovisual", 0, "2026-10-30", { ganho: "2026-11-10", resp: "Victor" }),
      L("l10", "Sabor da Esquina", "social", "Perdido", "Instagram", "Gestão de redes sociais", 1800, "2026-10-01", { perda: "Parou de responder" }),
      L("l11", "Mitra", "social", "Perdido", "Indicação", "", 0, "2026-09-15", { perda: "Não é o momento" }),
    ],
    produtos: [
      { id: "p1", name: "Gestão de redes sociais", tipo: "Recorrente", min: 1800, max: 3500, preco: "R$ 1.800 a R$ 3.500 por mês", arg: "Planejamento, produção e postagem guiados pelo Método NOVA." },
      { id: "p2", name: "Gestão de tráfego pago", tipo: "Recorrente", min: 1200, max: 1200, preco: "R$ 1.200 por mês, mais a verba", arg: "Anúncios que levam gente para o WhatsApp e para a mesa, com relatório mensal do custo por conversa." },
      { id: "p3", name: "Assessoria de marca", tipo: "Projeto", min: 4500, max: 6000, preco: "R$ 4.500 a R$ 6.000, projeto de 3 meses", arg: "Diagnóstico, posicionamento e plano de marca antes da gestão começar." },
      { id: "p4", name: "Gestão de Relacionamento", tipo: "Recorrente", min: 0, max: 0, preco: "Inclusa para clientes; cobra só o custo das mensagens do WhatsApp", arg: "Cadastro dos clientes do restaurante, campanhas e automações para trazer o cliente de volta." },
      { id: "p5", name: "Produção audiovisual", tipo: "Projeto", min: 0, max: 0, preco: "[DEFINA O PREÇO]", arg: "[ESCREVA O ARGUMENTO]" },
    ],
    cadencias: [{ id: "cad1", name: "Cadência padrão", passos: [{ title: "Follow-up 1", canal: "Mensagem", dias: 2 }, { title: "Follow-up 2", canal: "Mensagem", dias: 5 }, { title: "Follow-up 3", canal: "Ligar", dias: 10 }] }],
    segmentos: [
      { id: "sg1", name: "Respondeu e não virou call", funil: "", stages: ["Respondeu"], origens: [], parado: 3 },
      { id: "sg2", name: "Parou nos follow-ups", funil: "", stages: ["Follow-up 1", "Follow-up 2", "Follow-up 3"], origens: [], parado: 0 },
    ],
    scripts: [
      { id: "s1", cat: "Abordagem", title: "Primeira mensagem", text: "Oi, {nome}! Aqui é a Carol, da Agência Veka. Acompanho o perfil de vocês e gostei muito de {detalhe}. A gente cuida da presença digital de restaurantes aqui da região. Posso te mostrar em 15 minutos o que faríamos pelo {nome}?" },
      { id: "s2", cat: "Follow-up", title: "Follow-up 1", text: "Oi, {nome}! Passando para saber se você viu minha mensagem. Separei duas ideias de conteúdo para vocês, posso te mandar?" },
      { id: "s3", cat: "Follow-up", title: "Follow-up 2", text: "Oi! Montei um raio x rápido do perfil de vocês, com três pontos que dá para melhorar ainda neste mês. Quer que eu te envie?" },
      { id: "s4", cat: "Follow-up", title: "Follow-up 3", text: "Oi, {nome}! Última mensagem por aqui para não te incomodar. Se fizer sentido conversar mais para frente, é só me chamar." },
      { id: "s5", cat: "Objeção", title: "Achou caro", text: "Entendo. Para comparar, pensa em quantas mesas por mês pagam a gestão. Com o ticket de vocês, poucas mesas a mais já cobrem o investimento. Posso te mostrar como medimos isso nos nossos clientes?" },
      { id: "s6", cat: "Reunião", title: "Convite para a call", text: "Que bom! Vamos marcar 20 minutos com o Victor para ele entender o momento do {nome}? Tenho {dia} às {hora} ou {dia} às {hora}." },
      { id: "s7", cat: "Reunião", title: "Confirmação da call", text: "Oi, {nome}! Confirmando nossa conversa com o Victor {dia} às {hora}. Ele vai apresentar a proposta montada para vocês." },
    ],
    metas: [{ id: "2026-11", niveis: [{ nome: "Ritmo atual (R$ 1.000 de verba)", valor: 8100 }, { nome: "Ritmo da meta em 6 meses", valor: 16250 }] }],
  };
}

export const COLECOES = ["funis", "leads", "tasks", "sales", "metas", "produtos", "scripts", "cadencias", "automacoes", "segmentos", "campanhas"];

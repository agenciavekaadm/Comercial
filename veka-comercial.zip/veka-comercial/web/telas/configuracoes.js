import { useEffect, useState } from "preact/hooks";
import { html, Avatar, Icone, csvHref } from "../nucleo.js";
import { AbaSeguranca, senhaFraca } from "./seguranca.js";

const ABAS = [["perfil", "Perfil e senha"], ["seguranca", "Segurança"], ["equipe", "Equipe"], ["origens", "Origens"], ["motivos", "Motivos de perda"], ["integracoes", "Integrações"], ["dados", "Dados"]];
const PAPEIS = ["SDR", "Closer", "Sócia", "Sócio", "Gestão"];

function Perfil({ ctx }) {
  const { sb, eu, avisar, setEu } = ctx;
  const [f, setF] = useState({ nome: eu.nome || "", cargo: eu.cargo || "", telefone: eu.telefone || "" });
  const [senha, setSenha] = useState({ a: "", b: "" });
  const [msg, setMsg] = useState({ perfil: "", senha: "", erroSenha: "" });
  const [subindo, setSubindo] = useState(false);
  const [email, setEmail] = useState(eu.email || "");
  useEffect(() => { sb.auth.getUser().then(({ data }) => setEmail(data.user?.email || eu.email || "")); }, []);

  const salvarPerfil = async (e) => {
    e.preventDefault();
    if (!f.nome.trim()) { setMsg({ ...msg, perfil: "" }); avisar("O nome não pode ficar vazio."); return; }
    const dados = { nome: f.nome.trim(), cargo: f.cargo.trim(), telefone: f.telefone.trim(), email };
    const { error } = await sb.from("equipe").update(dados).eq("user_id", eu.user_id);
    if (error) { avisar("Não salvou: " + error.message); return; }
    setEu({ ...eu, ...dados });
    setMsg({ ...msg, perfil: "Perfil salvo." });
  };
  const trocarFoto = async (e) => {
    const arq = e.target.files?.[0];
    if (!arq) return;
    if (!/^image\//.test(arq.type) || arq.size > 3 * 1024 * 1024) { avisar("Use uma imagem de até 3 MB."); return; }
    setSubindo(true);
    const caminho = eu.user_id + "/" + Date.now() + "." + (arq.name.split(".").pop() || "jpg");
    const { error } = await sb.storage.from("avatares").upload(caminho, arq, { upsert: false, contentType: arq.type });
    if (error) { setSubindo(false); avisar("Não subiu a foto: " + error.message); return; }
    const url = sb.storage.from("avatares").getPublicUrl(caminho).data.publicUrl;
    await sb.from("equipe").update({ foto_url: url }).eq("user_id", eu.user_id);
    setEu({ ...eu, foto_url: url });
    setSubindo(false);
  };
  const trocarSenha = async (e) => {
    e.preventDefault();
    const fraca = senhaFraca(senha.a);
    if (fraca) { setMsg({ ...msg, erroSenha: fraca, senha: "" }); return; }
    if (senha.a !== senha.b) { setMsg({ ...msg, erroSenha: "As duas senhas não são iguais.", senha: "" }); return; }
    const { error } = await sb.auth.updateUser({ password: senha.a });
    if (error) { setMsg({ ...msg, erroSenha: "Não foi possível trocar: " + error.message, senha: "" }); return; }
    setSenha({ a: "", b: "" });
    setMsg({ ...msg, erroSenha: "", senha: "Senha alterada." });
  };
  const campo = (k, rot, tipo = "text") => html`<label class="campo">${rot}<input class="inp" type=${tipo} value=${f[k]} onInput=${(e) => setF({ ...f, [k]: e.target.value })} /></label>`;
  return html`
    <form class="card secao" onSubmit=${salvarPerfil}>
      <h2>Perfil</h2>
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
        <${Avatar} pessoa=${eu} grande />
        <label class="btn">${subindo ? "Enviando…" : eu.foto_url ? "Trocar foto" : "Adicionar foto"}<input type="file" accept="image/*" class="sr" onChange=${trocarFoto} /></label>
      </div>
      <div class="form">
        ${campo("nome", "Nome")}
        ${campo("cargo", "Cargo")}
        ${campo("telefone", "Telefone", "tel")}
        <label class="campo">E-mail<input class="inp" value=${email} disabled /></label>
      </div>
      <p class="dica">O e-mail é o seu login e não muda por aqui. Papel no comercial: ${eu.papel}${eu.admin ? " · administradora do sistema" : ""}.</p>
      ${msg.perfil && html`<p class="okmsg" role="status">${msg.perfil}</p>`}
      <div class="acoes"><button class="btn prim" type="submit">Salvar perfil</button></div>
    </form>
    <form class="card secao" onSubmit=${trocarSenha}>
      <h2>Alterar senha</h2>
      <div class="form">
        <label class="campo">Nova senha<input class="inp" type="password" autocomplete="new-password" value=${senha.a} onInput=${(e) => setSenha({ ...senha, a: e.target.value })} /></label>
        <label class="campo">Confirmar senha<input class="inp" type="password" autocomplete="new-password" value=${senha.b} onInput=${(e) => setSenha({ ...senha, b: e.target.value })} /></label>
      </div>
      ${msg.erroSenha && html`<p class="erro" role="alert">${msg.erroSenha}</p>`}
      ${msg.senha && html`<p class="okmsg" role="status">${msg.senha}</p>`}
      <div class="acoes"><button class="btn prim" type="submit">Alterar senha</button></div>
    </form>
    <div class="card secao" style="flex-direction:row;justify-content:space-between;align-items:center;flex-wrap:wrap">
      <div><h2>Sair da conta</h2><p class="dica">Encerra a sessão neste aparelho.</p></div>
      <button class="btn perigo" type="button" onClick=${() => sb.auth.signOut()}><${Icone} n="sair" t=${16} />Sair</button>
    </div>`;
}

function Equipe({ ctx }) {
  const { sb, eu, equipe, avisar, recarregarEquipe } = ctx;
  const [novo, setNovo] = useState(null);
  const [erro, setErro] = useState("");
  const [ocupado, setOcupado] = useState(false);
  const mudar = async (p, patch) => {
    const { error } = await sb.from("equipe").update(patch).eq("user_id", p.user_id);
    if (error) avisar(error.message); else recarregarEquipe();
  };
  const convidar = async (e) => {
    e.preventDefault();
    const fraca = senhaFraca(novo.senha);
    if (fraca) { setErro("Senha provisória fraca. " + fraca); return; }
    setErro(""); setOcupado(true);
    const { data, error } = await sb.functions.invoke("convidar-membro", { body: novo });
    setOcupado(false);
    let m = data?.erro;
    if (error && !m) { try { m = (await error.context.json()).erro; } catch (_) { m = "Não foi possível criar o acesso agora."; } }
    if (m) { setErro(m); return; }
    avisar(novo.nome + " já pode entrar com o e-mail e a senha provisória.");
    setNovo(null); recarregarEquipe();
  };
  return html`
    <div class="card secao">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
        <h2>Equipe do comercial</h2>
        ${eu.admin && !novo && html`<button class="btn prim" type="button" onClick=${() => setNovo({ nome: "", email: "", papel: "SDR", senha: "" })}><${Icone} n="mais" t=${16} e=${2.4} />Adicionar pessoa</button>`}
      </div>
      ${novo && html`
        <form class="form" onSubmit=${convidar} style="background:var(--soft);padding:16px;border-radius:12px">
          <label class="campo">Nome<input class="inp" value=${novo.nome} onInput=${(e) => setNovo({ ...novo, nome: e.target.value })} /></label>
          <label class="campo">E-mail<input class="inp" type="email" value=${novo.email} onInput=${(e) => setNovo({ ...novo, email: e.target.value })} /></label>
          <label class="campo">Papel<select class="inp" value=${novo.papel} onChange=${(e) => setNovo({ ...novo, papel: e.target.value })}>${PAPEIS.map((p) => html`<option>${p}</option>`)}</select></label>
          <label class="campo">Senha provisória<input class="inp" type="text" value=${novo.senha} onInput=${(e) => setNovo({ ...novo, senha: e.target.value })} placeholder="10 ou mais, letras e números" /></label>
          ${erro && html`<p class="erro full" role="alert">${erro}</p>`}
          <p class="dica full">Passe a senha provisória por um canal privado. A pessoa troca a senha em Configurações, Perfil e senha.</p>
          <div class="acoes full"><button class="btn" type="button" onClick=${() => { setNovo(null); setErro(""); }}>Cancelar</button><button class="btn prim" type="submit" disabled=${ocupado}>${ocupado ? "Criando…" : "Criar acesso"}</button></div>
        </form>`}
      <div>
        ${equipe.map((p) => html`
          <div class="linha-lista" style=${p.ativo ? "" : "opacity:.55"}>
            <${Avatar} pessoa=${p} />
            <div style="flex:1;min-width:0">
              <div style="font-weight:700">${p.nome} ${p.admin ? html`<span class="tag azul">Admin</span>` : ""} ${!p.ativo ? html`<span class="tag err">Sem acesso</span>` : ""}</div>
              <div class="dica">${[p.cargo, p.email].filter(Boolean).join(" · ") || "Perfil ainda não preenchido"}</div>
            </div>
            ${eu.admin ? html`
              <label><span class="sr">Papel de ${p.nome}</span><select class="inp" style="height:36px;width:auto" value=${p.papel} onChange=${(e) => mudar(p, { papel: e.target.value })}>${[...new Set([...PAPEIS, p.papel])].map((x) => html`<option>${x}</option>`)}</select></label>
              ${p.user_id !== eu.user_id && html`
                <button class="btn peq" type="button" onClick=${() => mudar(p, { admin: !p.admin })}>${p.admin ? "Tirar admin" : "Tornar admin"}</button>
                <button class=${"btn peq" + (p.ativo ? " perigo" : "")} type="button" onClick=${() => mudar(p, { ativo: !p.ativo })}>${p.ativo ? "Tirar acesso" : "Devolver acesso"}</button>`}`
            : html`<span class="tag">${p.papel}</span>`}
          </div>`)}
      </div>
      ${!eu.admin && html`<p class="dica">Só administradores adicionam pessoas e mudam papéis.</p>`}
    </div>`;
}

function Lista({ ctx, chave, titulo, texto, exemplo }) {
  const { s, salvar } = ctx;
  const itens = s.config?.[chave] || [];
  const [novo, setNovo] = useState("");
  const usados = (v) => s.leads.filter((l) => (chave === "origens" ? l.origem : l.perda) === v).length;
  const gravar = (lista) => salvar("config", { ...s.config, [chave]: lista });
  const add = (e) => {
    e.preventDefault();
    const v = novo.trim();
    if (!v || itens.some((x) => x.toLowerCase() === v.toLowerCase())) return;
    gravar([...itens, v]); setNovo("");
  };
  const mover = (i, d) => { const l = itens.slice(); const j = i + d; if (j < 0 || j >= l.length) return; [l[i], l[j]] = [l[j], l[i]]; gravar(l); };
  return html`
    <div class="card secao">
      <h2>${titulo}</h2>
      <p class="dica">${texto}</p>
      <div>
        ${itens.map((v, i) => html`
          <div class="linha-lista">
            <span style="flex:1;font-weight:700">${v}</span>
            <span class="dica">${usados(v)} leads</span>
            <button class="seta" type="button" aria-label=${"Subir " + v} disabled=${i === 0} onClick=${() => mover(i, -1)}><${Icone} n="esq" t=${12} e=${2.6} /></button>
            <button class="seta" type="button" aria-label=${"Descer " + v} disabled=${i === itens.length - 1} onClick=${() => mover(i, 1)}><${Icone} n="dir" t=${12} e=${2.6} /></button>
            <button class="btn peq perigo" type="button" onClick=${() => gravar(itens.filter((x) => x !== v))}>Remover</button>
          </div>`)}
      </div>
      <form onSubmit=${add} style="display:flex;gap:8px">
        <label style="flex:1"><span class="sr">Novo item</span><input class="inp" value=${novo} onInput=${(e) => setNovo(e.target.value)} placeholder=${exemplo} /></label>
        <button class="btn prim" type="submit">Adicionar</button>
      </form>
    </div>`;
}

function Integracoes({ ctx }) {
  const { sb } = ctx;
  const [st, setSt] = useState(null);
  useEffect(() => {
    (async () => {
      const r = {};
      for (const canal of ["WhatsApp", "Instagram"]) {
        const { data, count } = await sb.from("conversas").select("ultima_entrada_em", { count: "exact" }).eq("canal", canal).order("ultima_entrada_em", { ascending: false, nullsFirst: false }).limit(1);
        r[canal] = { n: count || 0, ultima: data?.[0]?.ultima_entrada_em };
      }
      setSt(r);
    })();
  }, []);
  const linha = (nome, desc, est) => html`
    <div class="linha-lista">
      <div style="flex:1"><div style="font-weight:700">${nome}</div><div class="dica">${desc}</div></div>
      ${est}
    </div>`;
  const estado = (c) => !st ? html`<span class="tag">Verificando…</span>` : st[c].n ? html`<span class="tag ok">Recebendo · última em ${new Date(st[c].ultima).toLocaleDateString("pt-BR")}</span>` : html`<span class="tag warn">Sem mensagens ainda</span>`;
  return html`
    <div class="card secao">
      <h2>Integrações</h2>
      <div>
        ${linha("Banco de dados (Supabase)", "Guarda leads, tarefas, vendas e conversas. Login da equipe.", html`<span class="tag ok">Conectado</span>`)}
        ${linha("WhatsApp", "API oficial da Meta. Configurada nos segredos do servidor (passo a passo, etapa 2).", estado("WhatsApp"))}
        ${linha("Instagram", "API de login do Instagram. O token vence a cada 60 dias.", estado("Instagram"))}
        ${linha("Google Agenda", "Mandar as atividades para a agenda de cada pessoa.", html`<span class="tag">Próxima etapa</span>`)}
      </div>
      <p class="dica">Tokens e chaves secretas ficam só no servidor (Supabase, Edge Functions, Secrets). Nunca aparecem nesta tela.</p>
    </div>`;
}

function Dados({ ctx }) {
  const { s, sb } = ctx;
  const nomeFunil = (id) => s.funis.find((f) => f.id === id)?.name || "";
  const leadsCsv = csvHref([["Nome", "Instagram", "WhatsApp", "Funil", "Etapa", "Origem", "Serviço", "Valor", "Entrada", "Responsável", "Motivo de perda"], ...s.leads.map((l) => [l.name, l.insta, l.whats, nomeFunil(l.funil), l.stage, l.origem, l.servico, l.valor, l.criado, l.resp, l.perda])]);
  const backup = async () => {
    const { data } = await sb.from("itens").select("colecao, id, dados, atualizado_em");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    a.download = "veka-comercial-backup-" + new Date().toISOString().slice(0, 10) + ".json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };
  return html`
    <div class="card secao">
      <h2>Dados</h2>
      <p class="dica">Tudo fica no banco da Veka, no Supabase. Baixe uma cópia quando quiser.</p>
      <div class="barra">
        <a class="btn" href=${leadsCsv} download="leads-veka.csv"><${Icone} n="baixar" t=${16} />Leads em planilha (CSV)</a>
        <button class="btn" type="button" onClick=${backup}><${Icone} n="baixar" t=${16} />Cópia completa (JSON)</button>
      </div>
      <p class="dica">${s.leads.length} leads · ${s.tasks.length} tarefas · ${s.sales.length} vendas · ${s.scripts.length} scripts</p>
    </div>`;
}

export function Configuracoes({ ctx }) {
  const [aba, setAba] = useState("perfil");
  return html`
    <div class="topo"><div><h1>Configurações</h1><p>Perfil, senha, equipe e dados da conta.</p></div></div>
    <div class="config">
      <nav class="card config-menu" aria-label="Seções">
        ${ABAS.map(([k, n]) => html`<button type="button" aria-current=${aba === k ? "true" : "false"} onClick=${() => setAba(k)}>${n}</button>`)}
      </nav>
      <div class="config-corpo">
        ${aba === "perfil" && html`<${Perfil} ctx=${ctx} />`}
        ${aba === "equipe" && html`<${Equipe} ctx=${ctx} />`}
        ${aba === "origens" && html`<${Lista} ctx=${ctx} chave="origens" titulo="Origens dos leads" texto="De onde o lead veio. Aparece no cadastro, na captura rápida e nos filtros." exemplo="Ex.: Feira gastronômica" />`}
        ${aba === "motivos" && html`<${Lista} ctx=${ctx} chave="motivos" titulo="Motivos de perda" texto="Por que o lead saiu do funil. Pedido ao mover um lead para Perdido." exemplo="Ex.: Fechou com freelancer" />`}
        ${aba === "integracoes" && html`<${Integracoes} ctx=${ctx} />`}
        ${aba === "dados" && html`<${Dados} ctx=${ctx} />`}
        ${aba === "seguranca" && html`<${AbaSeguranca} ctx=${ctx} />`}
      </div>
    </div>`;
}

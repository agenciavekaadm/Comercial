import { useState } from "preact/hooks";
import { html, ETAPAS, COR_ETAPA, brl, pct, hoje, iso, csvHref, Icone } from "../nucleo.js";

const RESP = ["Respondeu", "Follow-up 1", "Follow-up 2", "Follow-up 3", "Convertido"];
const FOLLOW = ["Follow-up 1", "Follow-up 2", "Follow-up 3"];

function contar(ls) {
  const abord = ls.filter((l) => l.stage !== "Solicitações recebidas").length;
  const conv = ls.filter((l) => l.stage === "Convertido").length;
  const resp = ls.filter((l) => RESP.includes(l.stage)).length;
  return { leads: ls.length, abord, conv, resp, follow: ls.filter((l) => FOLLOW.includes(l.stage)).length, lost: ls.filter((l) => l.stage === "Perdido").length, txResp: pct(resp, abord), txConv: pct(conv, abord) };
}

export function Painel({ ctx }) {
  const { s, eu, salvar } = ctx;
  const [periodo, setPeriodo] = useState("tudo");
  const [funil, setFunil] = useState("todos");
  const [editar, setEditar] = useState(false);
  const d7 = new Date(); d7.setDate(d7.getDate() - 6);
  const inicioMes = hoje().slice(0, 8) + "01";
  const inicio = { hoje: hoje(), "7": iso(d7), mes: inicioMes, tudo: "" }[periodo];
  const ROT = { hoje: "Hoje", "7": "Últimos 7 dias", mes: "Este mês", tudo: "Todo o período" };
  const noPeriodo = (l) => !inicio || (l.criado || "") >= inicio;
  const leads = s.leads.filter((l) => (funil === "todos" || l.funil === funil) && noPeriodo(l));
  const st = contar(leads);
  const soma = (ls) => ls.reduce((n, l) => n + (Number(l.valor) || 0), 0);
  const abertos = leads.filter((l) => !["Convertido", "Perdido", "Solicitações recebidas"].includes(l.stage));
  const ganhos = leads.filter((l) => l.stage === "Convertido");
  const perdidos = leads.filter((l) => l.stage === "Perdido");
  const kpis = [
    ["Total de leads", st.leads, st.abord + " abordados", "var(--link)"],
    ["Em follow-up", st.follow, "aguardando retorno", "var(--warn)"],
    ["Convertidos", st.conv, "de " + st.abord + " abordados", "var(--ok)"],
    ["Taxa de conversão", st.txConv, "convertidos sobre abordados", "var(--roxo)"],
    ["Em negociação", brl(soma(abertos)), abertos.length + " em aberto agora", "var(--link)"],
    ["Ganho", brl(soma(ganhos)), ganhos.length + " oportunidades ganhas", "var(--ok)"],
    ["Perdido", brl(soma(perdidos)), perdidos.length + " que saíram pela porta", "var(--err)"],
    ["Ticket médio", brl(ganhos.length ? soma(ganhos) / ganhos.length : 0), "por oportunidade ganha", "var(--warn)"],
  ];
  const max = Math.max(1, ...ETAPAS.map((e) => leads.filter((l) => l.stage === e).length));
  const mes = contar(s.leads.filter((l) => (l.criado || "") >= inicioMes));
  const ma = s.config?.metasAtiv || {};
  const metas = [["abordagens", "Abordagens", mes.abord], ["respostas", "Respostas", mes.resp], ["conversoes", "Conversões", mes.conv]];
  const meus = s.tasks.filter((t) => !t.done && t.resp === eu.nome && t.date <= hoje()).length;
  const nomeFunil = (id) => s.funis.find((f) => f.id === id)?.name || "";
  const csv = csvHref([["Nome", "Instagram", "WhatsApp", "Funil", "Etapa", "Origem", "Serviço", "Valor", "Entrada", "Responsável"], ...leads.map((l) => [l.name, l.insta, l.whats, nomeFunil(l.funil), l.stage, l.origem, l.servico, l.valor, l.criado, l.resp])]);
  const funis = s.funis.slice().sort((a, b) => (a.ordem || 0) - (b.ordem || 0));

  return html`
    <div class="topo">
      <div><h1>Olá, ${eu.nome}</h1><p>${funil === "todos" ? "Todos os funis somados" : nomeFunil(funil)} · ${ROT[periodo]}${meus ? " · você tem " + meus + " tarefa(s) para hoje" : ""}</p></div>
      <div class="barra">
        <label class="campo" style="flex-direction:row;align-items:center">Funil
          <select class="inp" style="width:auto" value=${funil} onChange=${(e) => setFunil(e.target.value)}><option value="todos">Todos os funis</option>${funis.map((f) => html`<option value=${f.id}>${f.name}</option>`)}</select>
        </label>
        <a class="btn" href=${csv} download="leads-veka.csv"><${Icone} n="baixar" t=${16} />Exportar CSV</a>
      </div>
    </div>
    <div class="pilulas" role="group" aria-label="Período">
      ${["hoje", "7", "mes", "tudo"].map((k) => html`<button type="button" class="pilula" aria-pressed=${periodo === k ? "true" : "false"} onClick=${() => setPeriodo(k)}>${ROT[k]}</button>`)}
    </div>
    <div class="grade kpis">
      ${kpis.map(([r, v, sub, cor]) => html`<div class="card kpi"><span class="rot" style=${"color:" + cor}>${r}</span><span class="val">${v}</span><span class="sub">${sub}</span></div>`)}
    </div>
    <section class="card">
      <div class="pad" style="padding-bottom:6px"><h2 style="margin:0;font-size:18px">Resumo dos funis</h2></div>
      <div class="rolar"><table class="tabela" style="min-width:820px">
        <thead><tr><th>Funil</th><th>Leads</th><th>Abordados</th><th>Responderam</th><th>Em follow</th><th>Convertidos</th><th>Perdidos</th><th>Tx resposta</th><th>Tx conversão</th></tr></thead>
        <tbody>${funis.filter((f) => funil === "todos" || f.id === funil).map((f) => { const r = contar(s.leads.filter((l) => l.funil === f.id && noPeriodo(l))); return html`
          <tr><td><a href="#/funis" style="font-weight:700;text-decoration:none">${f.name}</a></td><td>${r.leads}</td><td>${r.abord}</td><td>${r.resp}</td><td>${r.follow}</td><td style="color:var(--ok);font-weight:700">${r.conv}</td><td style="color:var(--err)">${r.lost}</td><td>${r.txResp}</td><td style="font-weight:700">${r.txConv}</td></tr>`; })}</tbody>
      </table></div>
    </section>
    <div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(380px,1fr))">
      <section class="card secao">
        <h2>Leads por etapa</h2>
        ${ETAPAS.map((e) => { const n = leads.filter((l) => l.stage === e).length; return html`
          <div style="display:grid;grid-template-columns:170px minmax(0,1fr) 36px;gap:10px;align-items:center;font-size:13px">
            <span>${e}</span>
            <div class="barra-prog"><span style=${"width:" + Math.round((n / max) * 100) + "%;background:" + COR_ETAPA[e]}></span></div>
            <b style="text-align:right">${n}</b>
          </div>`; })}
      </section>
      <section class="card secao">
        <div style="display:flex;justify-content:space-between;align-items:center"><h2>Metas de atividade do mês</h2><button class="btn peq" type="button" onClick=${() => setEditar(!editar)}>${editar ? "Pronto" : "Definir metas"}</button></div>
        ${metas.map(([k, r, feito]) => { const alvo = Number(ma[k]) || 0; return html`
          <div style="display:flex;flex-direction:column;gap:7px">
            <div style="display:flex;justify-content:space-between;font-size:14px"><b>${r}</b><span style="color:var(--link)">${alvo ? feito + " de " + alvo : feito + ", meta não definida"}</span></div>
            <div class="barra-prog"><span style=${"width:" + (alvo ? Math.min(100, Math.round((feito / alvo) * 100)) : 0) + "%"}></span></div>
            ${editar && html`<label class="campo" style="flex-direction:row;align-items:center">Meta no mês<input class="inp" type="number" min="0" style="width:120px" value=${alvo} onChange=${(e) => salvar("config", { ...s.config, metasAtiv: { ...ma, [k]: Math.max(0, parseInt(e.target.value, 10) || 0) } })} /></label>`}
          </div>`; })}
        <p class="dica">As metas iniciais saem da conta dos R$ 1.000 de tráfego em 30 dias: 83 conversas e 2 a 3 clientes.</p>
      </section>
    </div>`;
}

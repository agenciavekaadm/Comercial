import { useState, useRef } from "preact/hooks";
import { html, ETAPAS, TIPOS, COR_ETAPA, brl, pct, hoje, br, emDias, uid, digitos, diasDesde, csvHref, moverLead, Modal, Icone } from "../nucleo.js";

const SUB = { "Solicitações recebidas": "Aguardando aprovação", "Abordado": "Primeira mensagem enviada", "Respondeu": "Hora de marcar a call", "Follow-up 1": "Sem retorno, 1ª tentativa", "Follow-up 2": "Sem retorno, 2ª tentativa", "Follow-up 3": "Última tentativa", "Convertido": "Contrato fechado", "Perdido": "Saiu do funil" };
const leadVazio = (funil) => ({ name: "", insta: "", whats: "", criado: hoje(), origem: "Instagram", stage: "Abordado", servico: "", valor: "", resp: "Carol", obs: "", funil });

export function Funis({ ctx }) {
  const { s, eu, equipe, salvar, apagar, avisar } = ctx;
  const funis = s.funis.slice().sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  const [fid, setFid] = useState((funis.find((f) => f.id === "social") || funis[0])?.id);
  const [vis, setVis] = useState("quadro");
  const [q, setQ] = useState("");
  const [ordem, setOrdem] = useState("criado");
  const [fOrig, setFOrig] = useState([]);
  const [fResp, setFResp] = useState("");
  const [pop, setPop] = useState("");
  const [modal, setModal] = useState(null);
  const [sobre, setSobre] = useState(null);
  const arrastando = useRef(null);
  const pessoas = equipe.filter((p) => p.ativo).map((p) => p.nome);
  const origens = s.config?.origens || [];
  const motivos = s.config?.motivos || [];
  const produtos = s.produtos.map((p) => p.name);
  const funil = funis.find((f) => f.id === fid) || funis[0];
  if (!funil) return html`<p class="dica">Nenhum funil ainda.</p>`;

  const todos = s.leads.filter((l) => l.funil === funil.id);
  let leads = todos;
  const qq = q.trim().toLowerCase();
  if (qq) leads = leads.filter((l) => l.name.toLowerCase().includes(qq) || (l.insta || "").toLowerCase().includes(qq) || (qq.length > 3 && digitos(l.whats).includes(digitos(qq)) && digitos(qq)));
  if (fOrig.length) leads = leads.filter((l) => fOrig.includes(l.origem));
  if (fResp) leads = leads.filter((l) => l.resp === fResp);
  const cmp = { criado: (a, b) => (b.criado || "").localeCompare(a.criado || ""), mudou: (a, b) => (b.mudou || "").localeCompare(a.mudou || ""), valor: (a, b) => (Number(b.valor) || 0) - (Number(a.valor) || 0), nome: (a, b) => a.name.localeCompare(b.name, "pt-BR", { sensitivity: "base" }) };
  leads = leads.slice().sort(cmp[ordem]);
  const proxima = (id) => s.tasks.filter((t) => t.leadId === id && !t.done).sort((a, b) => (a.date || "").localeCompare(b.date || ""))[0];

  const mover = async (lead, etapa) => {
    if (!lead || lead.stage === etapa) return;
    const r = moverLead(s, lead, etapa, eu.nome);
    await salvar("leads", r.lead);
    if (r.tarefas.length) { await salvar("tasks", r.tarefas); avisar(r.tarefas.length + " tarefa(s) agendada(s) pela automação."); }
    if (etapa === "Perdido") setModal({ tipo: "detalhe", id: lead.id });
  };

  const abord = todos.filter((l) => l.stage !== "Solicitações recebidas").length;
  const resp = todos.filter((l) => ["Respondeu", "Follow-up 1", "Follow-up 2", "Follow-up 3", "Convertido"].includes(l.stage)).length;
  const conv = todos.filter((l) => l.stage === "Convertido").length;
  const abertos = todos.filter((l) => !["Convertido", "Perdido", "Solicitações recebidas"].includes(l.stage));
  const metricas = [["Leads", todos.length], ["Abordados", abord], ["Responderam", resp], ["Em follow", todos.filter((l) => l.stage.startsWith("Follow")).length], ["Convertidos", conv, "var(--ok)"], ["Perdidos", todos.filter((l) => l.stage === "Perdido").length, "var(--err)"], ["Tx resposta", pct(resp, abord), "var(--link)"], ["Tx conversão", pct(conv, abord), "var(--ok)"]];
  const tabela = vis === "fechados" ? leads.filter((l) => ["Convertido", "Perdido"].includes(l.stage)) : leads;
  const csv = csvHref([["Nome", "Instagram", "WhatsApp", "Etapa", "Origem", "Serviço", "Valor", "Entrada", "Responsável", "Motivo de perda"], ...todos.map((l) => [l.name, l.insta, l.whats, l.stage, l.origem, l.servico, l.valor, l.criado, l.resp, l.perda])]);
  const nFiltros = fOrig.length + (fResp ? 1 : 0);

  return html`
    <div class="topo">
      <div>
        <label><span class="sr">Funil</span>
          <select class="inp" style="width:auto;height:50px;font-family:Sora,sans-serif;font-size:24px;font-weight:600;background:transparent;border-color:transparent;padding-left:0" value=${funil.id} onChange=${(e) => setFid(e.target.value)}>${funis.map((f) => html`<option value=${f.id}>${f.name}</option>`)}</select>
        </label>
        <p>${abertos.length} negociações abertas · ${brl(abertos.reduce((n, l) => n + (Number(l.valor) || 0), 0))} em negociação</p>
      </div>
      <button class="btn prim" type="button" onClick=${() => setModal({ tipo: "novo", f: leadVazio(funil.id) })}><${Icone} n="mais" t=${16} e=${2.4} />Nova negociação</button>
    </div>

    <div class="barra" style="position:relative">
      <div class="seg" role="group" aria-label="Visualização">${[["quadro", "Quadro"], ["lista", "Lista"], ["fechados", "Fechados"]].map(([k, n]) => html`<button type="button" aria-pressed=${vis === k ? "true" : "false"} onClick=${() => setVis(k)}>${n}</button>`)}</div>
      <label style="flex:1 1 200px;max-width:280px"><span class="sr">Buscar no funil</span><input class="inp" type="search" placeholder="Buscar nome, @ ou telefone" value=${q} onInput=${(e) => setQ(e.target.value)} /></label>
      <label class="campo" style="flex-direction:row;align-items:center">Ordenar<select class="inp" style="width:auto" value=${ordem} onChange=${(e) => setOrdem(e.target.value)}><option value="criado">Data de entrada</option><option value="mudou">Última modificação</option><option value="valor">Valor</option><option value="nome">Nome</option></select></label>
      <button class="btn" type="button" onClick=${() => setPop(pop === "cap" ? "" : "cap")}>Captura rápida</button>
      <button class="btn" type="button" style=${nFiltros ? "border-color:var(--blue)" : ""} onClick=${() => setPop(pop === "filtro" ? "" : "filtro")}>Filtros${nFiltros ? " (" + nFiltros + ")" : ""}</button>
      <button class="btn" type="button" onClick=${() => setPop(pop === "cfg" ? "" : "cfg")}>Configurações</button>
      ${pop === "cap" && html`<${Captura} ctx=${ctx} funil=${funil} origens=${origens} fechar=${() => setPop("")} />`}
      ${pop === "filtro" && html`
        <div class="card pad" style="position:absolute;top:50px;left:0;z-index:20;width:320px;display:flex;flex-direction:column;gap:10px">
          <b style="font-size:13px">Origem</b>
          ${origens.map((o) => html`<label style="display:flex;gap:10px;align-items:center;font-size:14px"><input type="checkbox" checked=${fOrig.includes(o)} onChange=${() => setFOrig(fOrig.includes(o) ? fOrig.filter((x) => x !== o) : [...fOrig, o])} />${o}</label>`)}
          <label class="campo">Responsável<select class="inp" value=${fResp} onChange=${(e) => setFResp(e.target.value)}><option value="">Todos</option>${pessoas.map((p) => html`<option>${p}</option>`)}</select></label>
          <div class="acoes"><button class="btn" type="button" onClick=${() => { setFOrig([]); setFResp(""); }}>Limpar</button><button class="btn prim" type="button" onClick=${() => setPop("")}>Aplicar</button></div>
        </div>`}
      ${pop === "cfg" && html`
        <div class="card" style="position:absolute;top:50px;right:0;z-index:20;width:240px;padding:6px;display:flex;flex-direction:column">
          ${[["auto", "Automações"], ["cad", "Cadências de follow-up"], ["renomear", "Renomear funil"], ["novofunil", "Criar outro funil"]].map(([k, n]) => html`<button type="button" class="btn" style="border:0;justify-content:flex-start" onClick=${() => { setPop(""); setModal({ tipo: k }); }}>${n}</button>`)}
          <a class="btn" style="border:0;justify-content:flex-start" href=${csv} download="funil-veka.csv">Exportar leads (CSV)</a>
        </div>`}
    </div>

    <div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px">
      ${metricas.map(([r, v, cor]) => html`<div class="card" style="padding:12px 14px"><div style="font-size:12px;color:var(--muted);font-weight:700">${r}</div><div style=${"font-family:Sora,sans-serif;font-size:21px;font-weight:600;color:" + (cor || "var(--text)")}>${v}</div></div>`)}
    </div>

    ${vis === "quadro" ? html`
      <div class="rolar" style="padding-bottom:8px"><div class="quadro">
        ${ETAPAS.map((etapa, ci) => { const cards = leads.filter((l) => l.stage === etapa); return html`
          <section class=${"coluna" + (sobre === etapa ? " sobre" : "")} aria-label=${etapa}
            onDragOver=${(e) => { e.preventDefault(); if (sobre !== etapa) setSobre(etapa); }}
            onDragLeave=${(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setSobre(null); }}
            onDrop=${(e) => { e.preventDefault(); setSobre(null); const l = s.leads.find((x) => x.id === arrastando.current); arrastando.current = null; mover(l, etapa); }}>
            <div class="col-topo" style=${"border-top-color:" + COR_ETAPA[etapa]}><h2>${etapa}</h2><span class="cont">${cards.length}</span></div>
            <span class="dica" style="font-size:12px;padding:0 4px">${SUB[etapa]}</span>
            ${cards.map((l) => { const t = proxima(l.id); const contato = [l.insta, l.whats].filter(Boolean).join(" · "); return html`
              <article class="cartao" draggable="true" onDragStart=${(e) => { arrastando.current = l.id; e.dataTransfer?.setData("text/plain", l.id); }}>
                <button type="button" class="nome" onClick=${() => setModal({ tipo: "detalhe", id: l.id })}>${l.name}</button>
                ${contato && html`<span style="font-size:12px;color:var(--link)">${contato}</span>`}
                <div style="display:flex;flex-wrap:wrap;gap:6px">
                  <span class="tag">${l.origem}</span>
                  ${Number(l.valor) > 0 && html`<span class="tag ok">${brl(l.valor)}/mês</span>`}
                  ${t && html`<span class=${"tag " + (t.date < hoje() ? "err" : "warn")}>${t.tipo} ${br(t.date)}</span>`}
                </div>
                <span class="dica" style="font-size:12px">Na etapa ${diasDesde(l.mudou)} · ${l.resp}</span>
                ${etapa === "Solicitações recebidas" ? html`
                  <div style="display:flex;gap:6px"><button class="btn peq prim" style="flex:1" type="button" onClick=${() => mover(l, "Abordado")}>Aprovar</button><button class="btn peq perigo" style="flex:1" type="button" onClick=${() => salvar("leads", { ...l, stage: "Perdido", perda: "Recusado na triagem", mudou: hoje(), hist: [{ t: hoje(), text: "Recusado na triagem · " + eu.nome }, ...(l.hist || [])] })}>Recusar</button></div>` : html`
                  <div class="setas">
                    <button class="seta" type="button" aria-label=${"Mover " + l.name + " para " + (ETAPAS[ci - 1] || "")} disabled=${ci === 0} onClick=${() => mover(l, ETAPAS[ci - 1])}><${Icone} n="esq" t=${12} e=${2.6} /></button>
                    <button class="seta" type="button" aria-label=${"Mover " + l.name + " para " + (ETAPAS[ci + 1] || "")} disabled=${ci === ETAPAS.length - 1} onClick=${() => mover(l, ETAPAS[ci + 1])}><${Icone} n="dir" t=${12} e=${2.6} /></button>
                  </div>`}
              </article>`; })}
            ${!cards.length && html`<span class="dica" style="margin:auto;font-size:13px">${etapa === "Solicitações recebidas" ? "Nenhuma solicitação" : "Solte cards aqui"}</span>`}
          </section>`; })}
      </div></div>` : html`
      <div class="card rolar"><table class="tabela" style="min-width:900px">
        <thead><tr><th>Lead</th><th>Etapa</th><th>Origem</th><th>Valor</th><th>Entrada</th><th>Responsável</th><th>${vis === "fechados" ? "Resultado" : "Próxima tarefa"}</th></tr></thead>
        <tbody>${tabela.map((l) => { const t = proxima(l.id); return html`<tr>
          <td><button type="button" class="nome" style="border:0;background:none;padding:0;font-weight:800;text-align:left" onClick=${() => setModal({ tipo: "detalhe", id: l.id })}>${l.name}</button><div class="dica" style="font-size:12px">${[l.insta, l.whats].filter(Boolean).join(" · ") || "sem contato"}</div></td>
          <td><label><span class="sr">Etapa de ${l.name}</span><select class="inp" style="height:36px;width:auto" value=${l.stage} onChange=${(e) => mover(l, e.target.value)}>${ETAPAS.map((x) => html`<option>${x}</option>`)}</select></label></td>
          <td>${l.origem}</td><td>${Number(l.valor) > 0 ? brl(l.valor) : "-"}</td><td>${br(l.criado)}</td><td>${l.resp}</td>
          <td>${vis === "fechados" ? (l.stage === "Convertido" ? "Ganho em " + br(l.ganho || l.mudou) : l.perda || "Motivo não informado") : t ? t.title + " · " + br(t.date) : "Nenhuma"}</td></tr>`; })}</tbody>
      </table>${!tabela.length && html`<div class="vazio">Nada por aqui com esses filtros.</div>`}</div>`}

    ${modal?.tipo === "novo" && html`<${NovoLead} ctx=${ctx} funil=${funil} inicial=${modal.f} pessoas=${pessoas} origens=${origens} produtos=${produtos} fechar=${() => setModal(null)} />`}
    ${modal?.tipo === "detalhe" && s.leads.find((l) => l.id === modal.id) && html`<${Detalhe} ctx=${ctx} lead=${s.leads.find((l) => l.id === modal.id)} pessoas=${pessoas} origens=${origens} produtos=${produtos} motivos=${motivos} mover=${mover} fechar=${() => setModal(null)} />`}
    ${modal?.tipo === "auto" && html`<${Automacoes} ctx=${ctx} funil=${funil} funis=${funis} pessoas=${pessoas} fechar=${() => setModal(null)} />`}
    ${modal?.tipo === "cad" && html`<${Cadencias} ctx=${ctx} fechar=${() => setModal(null)} />`}
    ${(modal?.tipo === "renomear" || modal?.tipo === "novofunil") && html`<${NomeFunil} ctx=${ctx} funil=${modal.tipo === "renomear" ? funil : null} funis=${funis} pronto=${(id) => { if (id) setFid(id); setModal(null); }} />`}`;
}

function Captura({ ctx, funil, origens, fechar }) {
  const { s, eu, salvar } = ctx;
  const [texto, setTexto] = useState("");
  const [origem, setOrigem] = useState(origens[1] || origens[0] || "Instagram");
  const [etapa, setEtapa] = useState("Solicitações recebidas");
  const [msg, setMsg] = useState("");
  const capturar = async () => {
    const tokens = texto.split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);
    if (!tokens.length) { setMsg("Cole pelo menos um @ ou telefone."); return; }
    const novos = []; const tarefas = []; let repetidos = 0;
    const existe = (insta, whats) => [...s.leads, ...novos].some((l) => (insta && (l.insta || "").toLowerCase() === insta.toLowerCase()) || (whats && digitos(l.whats) === digitos(whats)));
    for (const tk of tokens) {
      const tel = digitos(tk).length >= 8 && !/[a-z_]/i.test(tk.replace(/^@/, ""));
      const insta = tel ? "" : "@" + tk.replace(/^@/, "").replace(/^https?:\/\/(www\.)?instagram\.com\//, "").replace(/[/?#].*$/, "");
      const whats = tel ? tk : "";
      if (existe(insta, whats)) { repetidos++; continue; }
      const base = { id: uid("l"), name: insta ? insta.slice(1) : whats, insta, whats, funil: funil.id, stage: "", origem, servico: "", valor: 0, criado: hoje(), mudou: hoje(), obs: "", resp: "Carol", perda: "", ganho: "", hist: [] };
      const r = moverLead(s, base, etapa, eu.nome);
      novos.push({ ...r.lead, hist: [{ t: hoje(), text: "Entrou pela captura rápida" }] }); tarefas.push(...r.tarefas);
    }
    if (novos.length) await salvar("leads", novos);
    if (tarefas.length) await salvar("tasks", tarefas);
    setTexto(""); setMsg(novos.length + " adicionado(s)" + (repetidos ? ", " + repetidos + " já estava(m) no sistema" : "") + ".");
  };
  return html`
    <div class="card pad" style="position:absolute;top:50px;left:0;z-index:20;width:360px;max-width:100%;display:flex;flex-direction:column;gap:12px">
      <label class="campo">Cole o @ do Instagram ou o telefone. Vários de uma vez: um por linha ou separados por vírgula.<textarea class="inp" rows="4" value=${texto} onInput=${(e) => setTexto(e.target.value)} placeholder="@restaurante, (22) 99999-0000"></textarea></label>
      <label class="campo">Origem<select class="inp" value=${origem} onChange=${(e) => setOrigem(e.target.value)}>${origens.map((o) => html`<option>${o}</option>`)}</select></label>
      <label class="campo">Entra na etapa<select class="inp" value=${etapa} onChange=${(e) => setEtapa(e.target.value)}>${ETAPAS.map((o) => html`<option>${o}</option>`)}</select></label>
      ${msg && html`<p class="okmsg" role="status">${msg}</p>`}
      <div class="acoes"><button class="btn" type="button" onClick=${fechar}>Fechar</button><button class="btn prim" type="button" onClick=${capturar}>Capturar</button></div>
    </div>`;
}

function CamposLead({ f, set, pessoas, origens, produtos, comEtapa }) {
  const c = (k) => ({ value: f[k] ?? "", onInput: (e) => set({ ...f, [k]: e.target.value }) });
  const sel = (k) => ({ value: f[k] ?? "", onChange: (e) => set({ ...f, [k]: e.target.value }) });
  return html`
    <div class="form">
      <label class="campo full">Nome do lead<input class="inp" ...${c("name")} placeholder="Ex.: Restaurante Maré Alta" /></label>
      <label class="campo">Instagram<input class="inp" ...${c("insta")} placeholder="@perfil" /></label>
      <label class="campo">WhatsApp<input class="inp" type="tel" ...${c("whats")} placeholder="(22) 99999-0000" /></label>
      ${comEtapa && html`<label class="campo">Etapa<select class="inp" ...${sel("stage")}>${ETAPAS.map((o) => html`<option>${o}</option>`)}</select></label>`}
      <label class="campo">Origem<select class="inp" ...${sel("origem")}>${[...new Set([...origens, f.origem].filter(Boolean))].map((o) => html`<option>${o}</option>`)}</select></label>
      <label class="campo">Serviço<select class="inp" ...${sel("servico")}><option value="">Ainda não sei</option>${produtos.map((o) => html`<option>${o}</option>`)}</select></label>
      <label class="campo">Valor por mês (R$)<input class="inp" type="number" min="0" ...${c("valor")} /></label>
      <label class="campo">Responsável<select class="inp" ...${sel("resp")}>${[...new Set([...pessoas, f.resp].filter(Boolean))].map((o) => html`<option>${o}</option>`)}</select></label>
      <label class="campo full">Observação<textarea class="inp" rows="2" ...${c("obs")}></textarea></label>
    </div>`;
}

function NovoLead({ ctx, funil, inicial, pessoas, origens, produtos, fechar }) {
  const { s, eu, salvar, avisar } = ctx;
  const [f, setF] = useState(inicial);
  const [erro, setErro] = useState("");
  const gravar = async () => {
    if (!f.name.trim()) { setErro("Escreva o nome do lead."); return; }
    if (!f.insta.trim() && !f.whats.trim()) { setErro("Preencha o Instagram ou o WhatsApp."); return; }
    const dup = s.leads.find((l) => (f.insta.trim() && (l.insta || "").toLowerCase() === f.insta.trim().toLowerCase()) || (digitos(f.whats).length >= 8 && digitos(l.whats) === digitos(f.whats)));
    if (dup) { setErro("Esse contato já está no sistema como " + dup.name + " (" + dup.stage + ")."); return; }
    const base = { ...f, id: uid("l"), name: f.name.trim(), insta: f.insta.trim(), whats: f.whats.trim(), valor: Number(f.valor) || 0, stage: "", mudou: hoje(), perda: "", ganho: "", hist: [] };
    const r = moverLead(s, base, f.stage, eu.nome);
    await salvar("leads", r.lead);
    if (r.tarefas.length) await salvar("tasks", r.tarefas);
    avisar(base.name + " entrou em " + f.stage + ".");
    fechar();
  };
  return html`<${Modal} titulo="Nova negociação" fechar=${fechar}>
    <${CamposLead} f=${f} set=${setF} pessoas=${pessoas} origens=${origens} produtos=${produtos} comEtapa />
    <p class="dica">Preencha ao menos o Instagram ou o WhatsApp. É por eles que o sistema evita lead repetido.</p>
    ${erro && html`<p class="erro" role="alert">${erro}</p>`}
    <div class="acoes"><button class="btn" type="button" onClick=${fechar}>Cancelar</button><button class="btn prim" type="button" onClick=${gravar}>Adicionar</button></div>
  <//>`;
}

function Detalhe({ ctx, lead, pessoas, origens, produtos, motivos, mover, fechar }) {
  const { s, eu, salvar, apagar } = ctx;
  const [f, setF] = useState({ ...lead, valor: lead.valor || "" });
  const [t, setT] = useState({ title: "", tipo: "Mensagem", date: emDias(1) });
  const [nota, setNota] = useState("");
  const [erro, setErro] = useState("");
  const [confirma, setConfirma] = useState(false);
  const tarefas = s.tasks.filter((x) => x.leadId === lead.id).sort((a, b) => (a.date || "").localeCompare(b.date || ""));
  const wa = digitos(lead.whats);
  const gravar = async () => {
    if (!f.name.trim()) { setErro("O nome não pode ficar vazio."); return; }
    const mudouEtapa = f.stage !== lead.stage;
    const dados = { ...lead, name: f.name.trim(), insta: f.insta.trim(), whats: f.whats.trim(), origem: f.origem, servico: f.servico, valor: Number(f.valor) || 0, resp: f.resp, obs: f.obs, perda: f.stage === "Perdido" ? f.perda : "" };
    if (mudouEtapa) await mover(dados, f.stage); else await salvar("leads", dados);
    fechar();
  };
  const addTarefa = async () => {
    if (!t.title.trim()) { setErro("Escreva o que precisa ser feito."); return; }
    await salvar("tasks", { id: uid("t"), leadId: lead.id, title: t.title.trim(), tipo: t.tipo, date: t.date || hoje(), hora: "", done: false, resp: lead.resp });
    setT({ title: "", tipo: "Mensagem", date: emDias(1) }); setErro("");
  };
  const addNota = async () => {
    if (!nota.trim()) return;
    await salvar("leads", { ...lead, hist: [{ t: hoje(), text: nota.trim() + " · " + eu.nome }, ...(lead.hist || [])] });
    setNota("");
  };
  return html`<${Modal} titulo=${lead.name} larga fechar=${fechar}>
    <div class="barra">
      ${wa.length >= 10 && html`<a class="btn peq" href=${"https://wa.me/55" + wa.replace(/^55/, "")} target="_blank" rel="noopener">Abrir WhatsApp</a>`}
      ${lead.insta && html`<a class="btn peq" href=${"https://instagram.com/" + lead.insta.replace(/^@/, "")} target="_blank" rel="noopener">Abrir Instagram</a>`}
      <a class="btn peq" href="#/conversas">Ver conversas</a>
    </div>
    <${CamposLead} f=${f} set=${setF} pessoas=${pessoas} origens=${origens} produtos=${produtos} comEtapa />
    ${f.stage === "Perdido" && html`<label class="campo" style="color:var(--err)">Motivo da perda<select class="inp" value=${f.perda || ""} onChange=${(e) => setF({ ...f, perda: e.target.value })}><option value="">Escolha o motivo</option>${motivos.map((o) => html`<option>${o}</option>`)}</select></label>`}
    <section style="border-top:1px solid var(--line);padding-top:14px;display:flex;flex-direction:column;gap:10px">
      <h3 style="margin:0;font-size:15px">Tarefas</h3>
      ${tarefas.map((x) => html`<label style="display:flex;gap:10px;align-items:center;font-size:14px;min-height:34px"><input type="checkbox" checked=${x.done} onChange=${() => salvar("tasks", { ...x, done: !x.done })} /><span style=${"flex:1;" + (x.done ? "text-decoration:line-through;color:var(--muted)" : "")}>${x.tipo}: ${x.title}</span><span class="dica">${br(x.date)} · ${x.resp}</span></label>`)}
      <div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(0,1fr) minmax(0,1fr) auto;gap:8px;align-items:end">
        <label class="campo">Nova tarefa<input class="inp" value=${t.title} onInput=${(e) => setT({ ...t, title: e.target.value })} placeholder="Ex.: mandar raio x do perfil" /></label>
        <label class="campo">Tipo<select class="inp" value=${t.tipo} onChange=${(e) => setT({ ...t, tipo: e.target.value })}>${TIPOS.map((o) => html`<option>${o}</option>`)}</select></label>
        <label class="campo">Data<input class="inp" type="date" value=${t.date} onInput=${(e) => setT({ ...t, date: e.target.value })} /></label>
        <button class="btn" type="button" onClick=${addTarefa}>Agendar</button>
      </div>
    </section>
    <section style="border-top:1px solid var(--line);padding-top:14px;display:flex;flex-direction:column;gap:8px">
      <h3 style="margin:0;font-size:15px">Histórico</h3>
      <div style="display:flex;gap:8px"><label style="flex:1"><span class="sr">Nova anotação</span><input class="inp" value=${nota} onInput=${(e) => setNota(e.target.value)} placeholder="Anote o que aconteceu" /></label><button class="btn" type="button" onClick=${addNota}>Anotar</button></div>
      ${[...(lead.hist || []), { t: lead.criado, text: "Entrou no funil por " + lead.origem }].map((x) => html`<div style="display:flex;gap:10px;font-size:13px"><span class="dica" style="flex:0 0 52px">${br(x.t)}</span><span>${x.text}</span></div>`)}
    </section>
    ${erro && html`<p class="erro" role="alert">${erro}</p>`}
    <div class="acoes" style="justify-content:space-between">
      ${!eu.admin ? html`<span class="dica">Só administradores excluem leads. Para tirar do funil, mova para Perdido.</span>` : confirma ? html`<div class="barra"><span class="erro">Excluir o lead e as tarefas dele?</span><button class="btn peq perigo" type="button" onClick=${async () => { await apagar("tasks", tarefas.map((x) => x.id)); await apagar("leads", lead.id); fechar(); }}>Sim, excluir</button><button class="btn peq" type="button" onClick=${() => setConfirma(false)}>Manter</button></div>`
        : html`<button class="btn perigo" type="button" onClick=${() => setConfirma(true)}>Excluir lead</button>`}
      <div class="barra"><button class="btn" type="button" onClick=${fechar}>Cancelar</button><button class="btn prim" type="button" onClick=${gravar}>Salvar</button></div>
    </div>
  <//>`;
}

function Automacoes({ ctx, funil, funis, pessoas, fechar }) {
  const { s, eu, salvar, apagar } = ctx;
  const outros = funis.filter((f) => f.id !== funil.id);
  const [a, setA] = useState({ stage: "Abordado", acao: "atividade", tipo: "Mensagem", dias: 2, titulo: "", cadId: s.cadencias[0]?.id || "", resp: pessoas[0] || "", dest: outros[0]?.id || "" });
  const lista = s.automacoes.filter((x) => x.funil === funil.id);
  const texto = (x) => x.acao === "atividade" ? `agenda "${x.titulo || x.tipo}" para daqui a ${x.dias} dias` : x.acao === "cadencia" ? "aplica a cadência " + (s.cadencias.find((c) => c.id === x.cadId)?.name || "") : x.acao === "resp" ? "passa para " + x.resp : "move para o funil " + (funis.find((f) => f.id === x.dest)?.name || "");
  const sel = (k) => ({ value: a[k], onChange: (e) => setA({ ...a, [k]: e.target.value }) });
  return html`<${Modal} titulo=${"Automações · " + funil.name} larga fechar=${fechar}>
    <p class="dica">Quando um lead entra numa etapa deste funil, a ação roda sozinha.</p>
    ${lista.map((x) => html`<div class="linha-lista"><span style="flex:1">Entrou em <b>${x.stage}</b>: ${texto(x)}</span>${eu.admin && html`<button class="btn peq perigo" type="button" onClick=${() => apagar("automacoes", x.id)}>Remover</button>`}</div>`)}
    ${!lista.length && html`<p class="dica">Nenhuma automação neste funil ainda.</p>`}
    <div class="form" style="border-top:1px solid var(--line);padding-top:14px">
      <label class="campo">Quando o lead entrar em<select class="inp" ...${sel("stage")}>${ETAPAS.map((o) => html`<option>${o}</option>`)}</select></label>
      <label class="campo">Então<select class="inp" ...${sel("acao")}><option value="atividade">Agendar atividade</option><option value="cadencia">Aplicar cadência</option><option value="resp">Definir responsável</option>${outros.length > 0 && html`<option value="mover">Mover de funil</option>`}</select></label>
      ${a.acao === "atividade" && html`
        <label class="campo">Tipo<select class="inp" ...${sel("tipo")}>${TIPOS.map((o) => html`<option>${o}</option>`)}</select></label>
        <label class="campo">Em quantos dias<input class="inp" type="number" min="0" value=${a.dias} onInput=${(e) => setA({ ...a, dias: e.target.value })} /></label>
        <label class="campo full">Título<input class="inp" value=${a.titulo} onInput=${(e) => setA({ ...a, titulo: e.target.value })} placeholder="Ex.: mandar a primeira mensagem" /></label>`}
      ${a.acao === "cadencia" && html`<label class="campo">Cadência<select class="inp" ...${sel("cadId")}>${s.cadencias.map((c) => html`<option value=${c.id}>${c.name}</option>`)}</select></label>`}
      ${a.acao === "resp" && html`<label class="campo">Responsável<select class="inp" ...${sel("resp")}>${pessoas.map((p) => html`<option>${p}</option>`)}</select></label>`}
      ${a.acao === "mover" && html`<label class="campo">Para o funil<select class="inp" ...${sel("dest")}>${outros.map((f) => html`<option value=${f.id}>${f.name}</option>`)}</select></label>`}
    </div>
    <div class="acoes"><button class="btn" type="button" onClick=${fechar}>Fechar</button><button class="btn prim" type="button" onClick=${() => salvar("automacoes", { ...a, id: uid("a"), funil: funil.id, dias: Math.max(0, parseInt(a.dias, 10) || 0) })}>Salvar automação</button></div>
  <//>`;
}

function Cadencias({ ctx, fechar }) {
  const { s, eu, salvar, apagar } = ctx;
  const [ce, setCe] = useState(s.cadencias[0] ? JSON.parse(JSON.stringify(s.cadencias[0])) : null);
  const [erro, setErro] = useState("");
  const passo = (i, k, v) => setCe({ ...ce, passos: ce.passos.map((p, j) => (j === i ? { ...p, [k]: v } : p)) });
  const gravar = async () => {
    if (!ce?.name.trim()) { setErro("Dê um nome para a cadência."); return; }
    if (!ce.passos.length) { setErro("Adicione pelo menos um passo."); return; }
    await salvar("cadencias", ce); setErro("");
  };
  return html`<${Modal} titulo="Cadências de follow-up" larga fechar=${fechar}>
    <div class="pilulas">
      ${s.cadencias.map((c) => html`<button type="button" class="pilula" aria-pressed=${ce?.id === c.id ? "true" : "false"} onClick=${() => setCe(JSON.parse(JSON.stringify(c)))}>${c.name}</button>`)}
      <button type="button" class="pilula" style="border-style:dashed" onClick=${() => setCe({ id: uid("cad"), name: "Nova cadência", passos: [{ title: "Follow-up 1", canal: "Mensagem", dias: 2 }] })}>+ Nova cadência</button>
    </div>
    ${ce && html`
      <label class="campo">Nome<input class="inp" value=${ce.name} onInput=${(e) => setCe({ ...ce, name: e.target.value })} /></label>
      ${ce.passos.map((p, i) => html`
        <div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(0,1fr) 90px 44px;gap:8px;align-items:end">
          <label class="campo">Passo<input class="inp" value=${p.title} onInput=${(e) => passo(i, "title", e.target.value)} /></label>
          <label class="campo">Canal<select class="inp" value=${p.canal} onChange=${(e) => passo(i, "canal", e.target.value)}>${TIPOS.map((o) => html`<option>${o}</option>`)}</select></label>
          <label class="campo">Dias<input class="inp" type="number" min="0" value=${p.dias} onInput=${(e) => passo(i, "dias", Math.max(0, parseInt(e.target.value, 10) || 0))} /></label>
          <button class="x" type="button" aria-label=${"Remover " + p.title} onClick=${() => setCe({ ...ce, passos: ce.passos.filter((_, j) => j !== i) })}><${Icone} n="fechar" t=${12} e=${2.4} /></button>
        </div>`)}
      <div class="barra" style="justify-content:space-between">
        <button class="btn peq" type="button" onClick=${() => setCe({ ...ce, passos: [...ce.passos, { title: "Follow-up " + (ce.passos.length + 1), canal: "Mensagem", dias: 0 }] })}>+ Adicionar passo</button>
        ${eu.admin && s.cadencias.some((c) => c.id === ce.id) && html`<button class="btn peq perigo" type="button" onClick=${() => { apagar("cadencias", ce.id); setCe(null); }}>Excluir cadência</button>`}
      </div>
      <p class="dica">Os dias contam a partir do dia em que a cadência é aplicada ao lead.</p>`}
    ${erro && html`<p class="erro" role="alert">${erro}</p>`}
    <div class="acoes"><button class="btn" type="button" onClick=${fechar}>Fechar</button><button class="btn prim" type="button" disabled=${!ce} onClick=${gravar}>Salvar cadência</button></div>
  <//>`;
}

function NomeFunil({ ctx, funil, funis, pronto }) {
  const { salvar } = ctx;
  const [nome, setNome] = useState(funil?.name || "");
  const gravar = async () => {
    const n = nome.trim(); if (!n) return;
    if (funil) { await salvar("funis", { ...funil, name: n }); pronto(); return; }
    const novo = { id: uid("f"), name: n, ordem: funis.length + 1 };
    await salvar("funis", novo); pronto(novo.id);
  };
  return html`<${Modal} titulo=${funil ? "Renomear funil" : "Criar outro funil"} fechar=${() => pronto()}>
    <label class="campo">Nome do funil<input class="inp" value=${nome} onInput=${(e) => setNome(e.target.value)} placeholder="Ex.: Indicações" /></label>
    <div class="acoes"><button class="btn" type="button" onClick=${() => pronto()}>Cancelar</button><button class="btn prim" type="button" onClick=${gravar}>${funil ? "Renomear" : "Criar funil"}</button></div>
  <//>`;
}

import { html } from "../nucleo.js";

const O_QUE = {
  atividades: "Agenda da semana com as tarefas da Carol e do Victor, pendentes e atrasadas.",
  metas: "Vendas lançadas, níveis de meta de MRR, projeção do mês e o caminho até R$ 100 mil.",
  prospeccao: "Listas de perfis do Instagram e do Google Maps mandadas para aprovação no funil.",
  disparos: "Segmentos que se atualizam sozinhos e campanhas com a lista de envio pronta.",
  produtos: "Catálogo da Veka com preço e argumento de venda.",
  scripts: "Banco de scripts e o playbook do comercial.",
  contatos: "Todos os contatos, com busca e exportação.",
};

export function EmBreve({ rota, nome }) {
  return html`
    <div class="topo"><div><h1>${nome}</h1><p>${O_QUE[rota] || ""}</p></div></div>
    <div class="card vazio" style="padding:48px">
      <strong>Esta tela entra na próxima leva</strong>
      <span>Ela já funciona no protótipo e está sendo levada para o banco de dados. Os dados que ela usa já estão guardados aqui.</span>
      <a class="btn" href="#/funis" style="margin-top:8px">Ir para os Funis</a>
    </div>`;
}

import { useEffect, useState, useRef } from "preact/hooks";
import { html, digitos } from "../nucleo.js";

const JANELA = 24 * 3600 * 1000;
const COR = { WhatsApp: "var(--ok)", Instagram: "var(--roxo)" };

const hora = (s) => {
  if (!s) return "";
  const d = new Date(s), h = new Date(), on = new Date(); on.setDate(h.getDate() - 1);
  if (d.toDateString() === h.toDateString()) return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === on.toDateString()) return "ontem";
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
};
const fone = (n) => { const d = digitos(n); const m = d.match(/^55(\d{2})(\d{4,5})(\d{4})$/); return m ? `(${m[1]}) ${m[2]}-${m[3]}` : "+" + d; };
const nomeDe = (c) => c.nome || c.usuario || (c.canal === "WhatsApp" ? fone(c.contato_id) : "Contato do Instagram");
const Av = ({ c }) => html`<span class="av" style=${"background:" + COR[c.canal] + ";color:#fff"}>${(nomeDe(c).replace(/[^\p{L}\p{N}]/gu, "")[0] || "?").toUpperCase()}</span>`;

export function Conversas({ ctx }) {
  const { sb, s, equipe, avisar } = ctx;
  const [convs, setConvs] = useState([]);
  const [msgs, setMsgs] = useState([]);
  const [sel, setSel] = useState(null);
  const [arq, setArq] = useState(false);
  const [canal, setCanal] = useState("todas");
  const [resp, setResp] = useState("");
  const [q, setQ] = useState("");
  const [texto, setTexto] = useState("");
  const [erro, setErro] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [carregou, setCarregou] = useState(false);
  const [msgsOk, setMsgsOk] = useState(false);
  const [, tique] = useState(0);
  const selRef = useRef(null);
  const caixa = useRef(null);
  selRef.current = sel;

  const carregar = async () => {
    const { data } = await sb.from("conversas").select("*").order("ultima_msg_em", { ascending: false, nullsFirst: false }).limit(500);
    setConvs(data || []); setCarregou(true);
  };
  const carregarMsgs = async (id) => {
    const { data } = await sb.from("mensagens").select("*").eq("conversa_id", id).order("criada_em").limit(1000);
    if (selRef.current === id) { setMsgs(data || []); setMsgsOk(true); }
  };
  useEffect(() => {
    carregar();
    const canalRt = sb.channel("conversas-tela")
      .on("postgres_changes", { event: "*", schema: "public", table: "conversas" }, (p) => {
        setConvs((atual) => {
          if (p.eventType === "DELETE") return atual.filter((c) => c.id !== p.old.id);
          const l = atual.filter((c) => c.id !== p.new.id);
          return [p.new, ...l].sort((a, b) => String(b.ultima_msg_em || "").localeCompare(String(a.ultima_msg_em || "")));
        });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "mensagens" }, (p) => {
        if (!p.new || p.new.conversa_id !== selRef.current) return;
        setMsgs((atual) => [...atual.filter((m) => m.id !== p.new.id), p.new].sort((a, b) => String(a.criada_em).localeCompare(String(b.criada_em))));
      })
      .subscribe();
    const t = setInterval(() => tique((n) => n + 1), 60000);
    return () => { sb.removeChannel(canalRt); clearInterval(t); };
  }, []);
  useEffect(() => { if (caixa.current) caixa.current.scrollTop = caixa.current.scrollHeight; }, [msgs, sel]);

  const conv = convs.find((c) => c.id === sel);
  useEffect(() => {
    if (!sel) return;
    setMsgs([]); setMsgsOk(false); carregarMsgs(sel);
  }, [sel]);
  useEffect(() => {
    if (conv && conv.nao_lidas) sb.from("conversas").update({ nao_lidas: 0 }).eq("id", conv.id);
  }, [conv?.id, conv?.nao_lidas]);

  const qq = q.trim().toLowerCase();
  const base = convs.filter((c) => !!c.arquivada === arq);
  const lista = base.filter((c) => (canal === "todas" || c.canal === canal) && (!resp || (resp === "sem" ? !c.responsavel : c.responsavel === resp)) && (!qq || nomeDe(c).toLowerCase().includes(qq) || (c.usuario || "").toLowerCase().includes(qq) || (digitos(qq).length > 3 && String(c.contato_id).includes(digitos(qq)))));
  const pessoas = equipe.filter((p) => p.ativo).map((p) => p.nome);
  const resta = conv?.ultima_entrada_em ? new Date(conv.ultima_entrada_em).getTime() + JANELA - Date.now() : -1;
  const lead = conv && s.leads.find((l) => (conv.canal === "WhatsApp" ? digitos(l.whats).endsWith(digitos(conv.contato_id).slice(-8)) && digitos(l.whats).length >= 8 : conv.usuario && (l.insta || "").toLowerCase() === conv.usuario.toLowerCase()));

  const atualizar = (patch) => { setConvs((a) => a.map((c) => (c.id === conv.id ? { ...c, ...patch } : c))); sb.from("conversas").update(patch).eq("id", conv.id); };
  const enviar = async (e) => {
    e?.preventDefault();
    const t = texto.trim();
    if (!t || !conv) return;
    const falta = t.match(/\{(nome|detalhe|dia|hora)\}/);
    if (falta) { setErro("Ainda tem espaço para preencher no texto: " + falta[0]); return; }
    setErro(""); setEnviando(true);
    const { data, error } = await sb.functions.invoke("enviar-mensagem", { body: { conversa_id: conv.id, texto: t } });
    setEnviando(false);
    let m = data?.erro;
    if (error && !m) { try { m = (await error.context.json()).erro; } catch (_) { m = "Não foi possível enviar agora."; } }
    if (m) { setErro(m); return; }
    setTexto("");
  };
  const usarScript = (id) => { const sc = s.scripts.find((x) => x.id === id); if (sc && conv) setTexto(sc.text.split("{nome}").join(nomeDe(conv))); };

  let diaAnt = "";
  return html`
    <div class="topo">
      <div><h1>Conversas</h1><p>WhatsApp e Instagram da Veka, num lugar só.</p></div>
      <div class="seg" role="group" aria-label="Situação">
        <button type="button" aria-pressed=${!arq ? "true" : "false"} onClick=${() => { setArq(false); setSel(null); }}>Ativas ${convs.filter((c) => !c.arquivada).length}</button>
        <button type="button" aria-pressed=${arq ? "true" : "false"} onClick=${() => { setArq(true); setSel(null); }}>Arquivadas ${convs.filter((c) => c.arquivada).length}</button>
      </div>
    </div>
    <div class="conv">
      <section class="card conv-lista" aria-label="Lista de conversas">
        <div style="padding:12px;display:flex;flex-direction:column;gap:10px;border-bottom:1px solid var(--line)">
          <label><span class="sr">Buscar conversa</span><input class="inp" type="search" placeholder="Buscar nome, @ ou telefone" value=${q} onInput=${(e) => setQ(e.target.value)} /></label>
          <div class="pilulas">${[["todas", "Todas"], ["WhatsApp", "WhatsApp"], ["Instagram", "Instagram"]].map(([k, n]) => html`<button type="button" class="pilula" style="height:32px;font-size:12px" aria-pressed=${canal === k ? "true" : "false"} onClick=${() => setCanal(k)}>${n} ${base.filter((c) => k === "todas" || c.canal === k).length}</button>`)}</div>
          <div class="pilulas">${[["", "Todos"], ...pessoas.map((p) => [p, p]), ["sem", "Sem dono"]].map(([k, n]) => html`<button type="button" class="pilula" style="height:32px;font-size:12px" aria-pressed=${resp === k ? "true" : "false"} onClick=${() => setResp(k)}>${n}</button>`)}</div>
        </div>
        <div class="conv-itens">
          ${lista.map((c) => html`
            <button type="button" class="conv-item" aria-current=${c.id === sel ? "true" : "false"} onClick=${() => { setSel(c.id); setErro(""); }}>
              <${Av} c=${c} />
              <span style="flex:1;min-width:0;display:flex;flex-direction:column;gap:3px">
                <span style="display:flex;justify-content:space-between;gap:8px"><b style="font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${nomeDe(c)}</b><span class="dica" style="font-size:12px">${hora(c.ultima_msg_em)}</span></span>
                <span style="display:flex;justify-content:space-between;gap:8px"><span style="font-size:13px;color:var(--body);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${c.ultima_msg || "Sem mensagens"}</span>${c.nao_lidas > 0 && html`<span class="tag azul" style="background:var(--blue);color:#fff">${c.nao_lidas}</span>`}</span>
                <span class="dica" style="font-size:12px">${[c.canal, c.usuario, c.responsavel ? "com " + c.responsavel : "sem responsável"].filter(Boolean).join(" · ")}</span>
              </span>
            </button>`)}
          ${!lista.length && html`<div class="vazio"><strong>${carregou ? "Nenhuma conversa aqui" : "Carregando…"}</strong>${carregou && "As mensagens de WhatsApp e Instagram aparecem aqui assim que chegarem."}</div>`}
        </div>
      </section>
      <section class="card conv-chat" aria-label="Conversa aberta">
        ${!conv ? html`<div class="vazio" style="margin:auto"><strong>Selecione uma conversa</strong>Escolha alguém na lista para ler e responder por aqui.</div>` : html`
          <div style="padding:14px 16px;border-bottom:1px solid var(--line);display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;align-items:center">
            <div style="display:flex;gap:10px;align-items:center;min-width:0">
              <${Av} c=${conv} />
              <div><h2 style="margin:0;font-size:18px">${nomeDe(conv)}</h2><span class="dica">${conv.canal} · ${conv.canal === "WhatsApp" ? fone(conv.contato_id) : conv.usuario || "perfil do Instagram"}${lead ? " · lead em " + lead.stage : ""}</span></div>
            </div>
            <div class="barra">
              <label><span class="sr">Responsável</span><select class="inp" style="height:38px;width:auto" value=${conv.responsavel || ""} onChange=${(e) => atualizar({ responsavel: e.target.value || null })}><option value="">Sem responsável</option>${pessoas.map((p) => html`<option>${p}</option>`)}</select></label>
              ${lead ? html`<a class="btn peq" href="#/funis">Ver no funil</a>` : ""}
              <a class="btn peq" target="_blank" rel="noopener" href=${conv.canal === "WhatsApp" ? "https://wa.me/" + digitos(conv.contato_id) : conv.usuario ? "https://instagram.com/" + conv.usuario.replace(/^@/, "") : "https://instagram.com/direct/inbox/"}>Abrir no app</a>
              <button class="btn peq" type="button" onClick=${() => { atualizar({ arquivada: !conv.arquivada }); setSel(null); }}>${conv.arquivada ? "Desarquivar" : "Arquivar"}</button>
            </div>
          </div>
          <div class="msgs" ref=${caixa} aria-live="polite">
            ${msgs.map((m) => { const d = new Date(m.criada_em); const dia = d.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" }); const sep = dia !== diaAnt; diaAnt = dia; return html`
              ${sep && html`<span class="dia">${dia}</span>`}
              <div class=${"bolha " + m.direcao} style=${m.status === "falhou" ? "background:var(--err-bg);color:var(--text)" : ""}>
                <span class="t">${m.texto}</span>
                <span class="m">${[m.direcao === "saida" && m.enviado_por, d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }), m.direcao === "saida" && ({ enviada: "enviada", entregue: "entregue", lida: "lida", falhou: "não entregue" }[m.status] || m.status), m.erro].filter(Boolean).join(" · ")}</span>
              </div>`; })}
            ${!msgs.length && html`<span class="dica" style="margin:auto">${msgsOk ? "Nenhuma mensagem nesta conversa ainda." : "Carregando a conversa…"}</span>`}
          </div>
          <p class=${"janela " + (resta > 0 ? "ok" : "fechada")}>${resta > 0 ? "Janela de resposta aberta por mais " + (Math.floor(resta / 3600000) ? Math.floor(resta / 3600000) + " h " : "") + Math.floor((resta % 3600000) / 60000) + " min." : conv.canal === "WhatsApp" ? "Passaram 24 horas desde a última mensagem deste contato. Pela regra da Meta, só dá para retomar com uma mensagem de modelo aprovada. Use Abrir no app por enquanto." : "Passaram 24 horas desde a última mensagem deste contato. O Instagram só libera resposta quando ele escrever de novo."}</p>
          <form onSubmit=${enviar} style="padding:12px 16px 16px;display:flex;flex-direction:column;gap:8px">
            <div class="barra">
              <label class="campo" style="flex-direction:row;align-items:center">Usar script<select class="inp" style="height:36px;width:auto;max-width:260px" value="" onChange=${(e) => usarScript(e.target.value)}><option value="">Escolha</option>${s.scripts.map((x) => html`<option value=${x.id}>${x.cat} · ${x.title}</option>`)}</select></label>
              <span class="dica" style="font-size:12px">Enter envia · Shift + Enter quebra a linha</span>
            </div>
            <div style="display:flex;gap:8px;align-items:flex-end">
              <label style="flex:1"><span class="sr">Mensagem</span><textarea class="inp" rows="2" disabled=${resta <= 0} value=${texto} onInput=${(e) => setTexto(e.target.value)} onKeyDown=${(e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); enviar(); } }} placeholder="Escreva a resposta"></textarea></label>
              <button class="btn prim" type="submit" disabled=${enviando || resta <= 0}>${enviando ? "Enviando…" : "Enviar"}</button>
            </div>
            ${erro && html`<p class="erro" role="alert">${erro}</p>`}
          </form>`}
      </section>
    </div>`;
}

import { useEffect, useState } from "preact/hooks";
import { html, Icone } from "../nucleo.js";

export const senhaFraca = (s) => {
  if (s.length < 10) return "Use pelo menos 10 caracteres.";
  if (!/[a-zA-Z]/.test(s) || !/\d/.test(s)) return "Misture letras e números.";
  return "";
};

// Etapa 2 do login: o código de 6 números do aplicativo autenticador.
export function CodigoMfa({ sb }) {
  const [codigo, setCodigo] = useState("");
  const [erro, setErro] = useState("");
  const [ocupado, setOcupado] = useState(false);
  const verificar = async (e) => {
    e.preventDefault();
    setErro(""); setOcupado(true);
    const { data } = await sb.auth.mfa.listFactors();
    const fator = data?.totp?.[0];
    if (!fator) { setOcupado(false); setErro("Nenhum aplicativo autenticador encontrado para este acesso."); return; }
    const { error } = await sb.auth.mfa.challengeAndVerify({ factorId: fator.id, code: codigo.replace(/\D/g, "") });
    setOcupado(false);
    if (error) setErro("Código errado ou vencido. Confira no aplicativo e tente de novo.");
  };
  return html`
    <div class="login">
      <div class="lado">
        <div class="marca"><img src="veka.png" alt="" /><div><b>Veka</b><span>Comercial</span></div></div>
        <div><h2>Verificação em duas etapas</h2><p>Abra o aplicativo autenticador do seu celular e digite o código de 6 números da Veka Comercial.</p></div>
        <small style="color:#7f93b3">Agência Veka · Saquarema</small>
      </div>
      <div class="form-lado">
        <form onSubmit=${verificar} novalidate>
          <h1>Digite o código</h1>
          <label class="campo">Código do aplicativo<input class="inp" inputmode="numeric" autocomplete="one-time-code" maxlength="6" style="font-size:24px;letter-spacing:.3em;text-align:center" value=${codigo} onInput=${(e) => setCodigo(e.target.value)} autofocus /></label>
          ${erro && html`<p class="erro" role="alert">${erro}</p>`}
          <button class="btn prim" type="submit" disabled=${ocupado || codigo.replace(/\D/g, "").length !== 6}>Confirmar</button>
          <button class="btn" type="button" onClick=${() => sb.auth.signOut()}>Voltar para o login</button>
          <p class="dica">Perdeu o celular? Peça para a administradora tirar a verificação do seu acesso no Supabase (Authentication, Users).</p>
        </form>
      </div>
    </div>`;
}

// Liga a verificação: mostra o QR code, confere o primeiro código.
export function AtivarMfa({ sb, pronto, obrigatorio }) {
  const [fator, setFator] = useState(null);
  const [codigo, setCodigo] = useState("");
  const [erro, setErro] = useState("");
  useEffect(() => {
    (async () => {
      const { data: l } = await sb.auth.mfa.listFactors();
      for (const f of (l?.all || []).filter((x) => x.status !== "verified")) await sb.auth.mfa.unenroll({ factorId: f.id });
      const { data, error } = await sb.auth.mfa.enroll({ factorType: "totp", friendlyName: "Veka Comercial " + new Date().toISOString().slice(0, 16) });
      if (error) setErro("Não foi possível começar: " + error.message); else setFator(data);
    })();
  }, []);
  const confirmar = async (e) => {
    e.preventDefault();
    const { error } = await sb.auth.mfa.challengeAndVerify({ factorId: fator.id, code: codigo.replace(/\D/g, "") });
    if (error) { setErro("Código errado. Confira se o relógio do celular está certo e tente de novo."); return; }
    pronto();
  };
  return html`
    <form onSubmit=${confirmar} style="display:flex;flex-direction:column;gap:14px">
      ${obrigatorio && html`<p class="dica">A administradora pediu verificação em duas etapas para toda a equipe. Leva 1 minuto.</p>`}
      <ol style="margin:0;padding-left:20px;display:flex;flex-direction:column;gap:6px;font-size:14px;line-height:1.5">
        <li>Instale um aplicativo autenticador no celular: Google Authenticator ou Microsoft Authenticator.</li>
        <li>No aplicativo, toque em adicionar e aponte a câmera para o código abaixo.</li>
        <li>Digite o código de 6 números que aparecer.</li>
      </ol>
      ${fator ? html`
        <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
          <img src=${fator.totp.qr_code} alt="QR code para o aplicativo autenticador" width="168" height="168" style="background:#fff;border:1px solid var(--line);border-radius:12px;padding:8px" />
          <div class="dica" style="max-width:280px">Não consegue ler o QR code? Digite esta chave no aplicativo:<br /><code style="font-size:13px;word-break:break-all;color:var(--text)">${fator.totp.secret}</code></div>
        </div>
        <label class="campo" style="max-width:240px">Código de 6 números<input class="inp" inputmode="numeric" autocomplete="one-time-code" maxlength="6" style="font-size:20px;letter-spacing:.25em;text-align:center" value=${codigo} onInput=${(e) => setCodigo(e.target.value)} /></label>` : !erro && html`<p class="dica">Preparando o código…</p>`}
      ${erro && html`<p class="erro" role="alert">${erro}</p>`}
      <div class="acoes" style="justify-content:flex-start"><button class="btn prim" type="submit" disabled=${!fator || codigo.replace(/\D/g, "").length !== 6}>Ativar verificação</button></div>
    </form>`;
}

export function TelaAtivarObrigatorio({ sb, pronto }) {
  return html`
    <div class="conteudo" style="max-width:720px;margin:0 auto">
      <div class="topo"><div><h1>Proteja o seu acesso</h1><p>Antes de continuar, ative a verificação em duas etapas.</p></div><button class="btn" type="button" onClick=${() => sb.auth.signOut()}>Sair</button></div>
      <div class="card secao"><${AtivarMfa} sb=${sb} pronto=${pronto} obrigatorio /></div>
    </div>`;
}

const ACAO = { insert: "criou", update: "alterou", delete: "apagou" };
const COL = { leads: "lead", tasks: "tarefa", sales: "venda", metas: "meta", produtos: "produto", scripts: "script", cadencias: "cadência", automacoes: "automação", segmentos: "segmento", campanhas: "campanha", funis: "funil", config: "configuração" };

export function AbaSeguranca({ ctx }) {
  const { sb, s, eu, salvar, avisar } = ctx;
  const [fatores, setFatores] = useState(null);
  const [ativando, setAtivando] = useState(false);
  const [registro, setRegistro] = useState(null);
  const [filtro, setFiltro] = useState("");
  const seg = s.config?.seguranca || { exigir2fa: false, inatividade: 30 };
  const carregar = async () => { const { data } = await sb.auth.mfa.listFactors(); setFatores(data?.totp || []); };
  useEffect(() => { carregar(); }, []);
  useEffect(() => {
    if (!eu.admin) return;
    sb.from("auditoria").select("*").order("quando", { ascending: false }).limit(200).then(({ data }) => setRegistro(data || []));
  }, []);
  const desligar = async () => {
    if (seg.exigir2fa) { avisar("A verificação é obrigatória para a equipe. Um admin precisa desligar a exigência antes."); return; }
    for (const f of fatores) await sb.auth.mfa.unenroll({ factorId: f.id });
    carregar(); avisar("Verificação em duas etapas desligada.");
  };
  const ff = filtro.trim().toLowerCase();
  const linhas = (registro || []).filter((r) => !ff || [r.quem, r.resumo, COL[r.colecao]].join(" ").toLowerCase().includes(ff));
  return html`
    <div class="card secao">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
        <h2>Verificação em duas etapas</h2>
        ${fatores && (fatores.length ? html`<span class="tag ok">Ativada</span>` : html`<span class="tag warn">Desligada</span>`)}
      </div>
      <p class="dica">Além da senha, o sistema pede um código do aplicativo do seu celular. Se alguém descobrir a senha, ainda assim não entra.</p>
      ${fatores && !fatores.length && (ativando ? html`<${AtivarMfa} sb=${sb} pronto=${() => { setAtivando(false); carregar(); avisar("Verificação em duas etapas ativada."); }} />` : html`<div><button class="btn prim" type="button" onClick=${() => setAtivando(true)}>Ativar agora</button></div>`)}
      ${fatores && fatores.length > 0 && html`<div><button class="btn perigo" type="button" onClick=${desligar}>Desligar</button></div>`}
    </div>
    <div class="card secao">
      <h2>Sessões</h2>
      <p class="dica">O sistema sai sozinho depois de ${seg.inatividade || 30} minutos sem uso. Se esqueceu o sistema aberto em outro computador, encerre todas as sessões.</p>
      <div><button class="btn" type="button" onClick=${() => sb.auth.signOut({ scope: "global" })}><${Icone} n="sair" t=${16} />Sair de todos os aparelhos</button></div>
    </div>
    ${eu.admin && html`
      <div class="card secao">
        <h2>Regras da equipe</h2>
        <label style="display:flex;gap:12px;align-items:flex-start;font-size:14px">
          <input type="checkbox" style="width:18px;height:18px;margin-top:2px" checked=${!!seg.exigir2fa} onChange=${(e) => salvar("config", { ...s.config, seguranca: { ...seg, exigir2fa: e.target.checked } })} />
          <span><b>Exigir verificação em duas etapas de todos</b><br /><span class="dica">Quem ainda não ativou vai ser levado a ativar no próximo acesso.</span></span>
        </label>
        <label class="campo" style="max-width:280px">Sair sozinho depois de
          <select class="inp" value=${String(seg.inatividade || 30)} onChange=${(e) => salvar("config", { ...s.config, seguranca: { ...seg, inatividade: Number(e.target.value) } })}>
            ${[15, 30, 60, 120].map((m) => html`<option value=${m}>${m} minutos sem uso</option>`)}
          </select>
        </label>
        <p class="dica">Só administradores apagam leads, tarefas e configurações. O resto da equipe cria e altera.</p>
      </div>
      <div class="card secao">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
          <h2>Registro de atividades</h2>
          <label style="width:260px"><span class="sr">Filtrar registro</span><input class="inp" type="search" placeholder="Filtrar por pessoa ou lead" value=${filtro} onInput=${(e) => setFiltro(e.target.value)} /></label>
        </div>
        <p class="dica">Toda criação, alteração e exclusão fica anotada, com quem fez e quando. Só administradores veem.</p>
        ${registro === null ? html`<p class="dica">Carregando…</p>` : html`
          <div class="rolar"><table class="tabela" style="min-width:620px">
            <thead><tr><th>Quando</th><th>Quem</th><th>O que</th></tr></thead>
            <tbody>${linhas.map((r) => html`<tr>
              <td style="white-space:nowrap">${new Date(r.quando).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</td>
              <td>${r.quem || "Sistema"}</td>
              <td><span class=${"tag " + (r.acao === "delete" ? "err" : r.acao === "insert" ? "ok" : "azul")}>${ACAO[r.acao] || r.acao}</span> ${r.tabela === "equipe" ? "acesso de " : (COL[r.colecao] || r.colecao) + " "}<b>${r.resumo}</b></td>
            </tr>`)}</tbody>
          </table></div>
          ${!linhas.length && html`<div class="vazio">Nada registrado ainda.</div>`}`}
      </div>`}`;
}

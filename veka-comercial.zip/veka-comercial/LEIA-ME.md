# Veka Comercial · sistema com login e banco de dados

- `supabase/migrations/001_conversas.sql`, `002_sistema.sql` e `003_seguranca.sql`: rode os três, nessa ordem, no SQL Editor do Supabase.
- `supabase/functions/meta-webhook`: recebe WhatsApp e Instagram (Enforce JWT verification desligado).
- `supabase/functions/enviar-mensagem`: envia as respostas (JWT ligado).
- `supabase/functions/convidar-membro`: cria acesso para pessoas novas da equipe (JWT ligado).
- `web/`: o sistema. Preencha a URL e a chave pública em `web/config.js` e publique a pasta inteira (Netlify Drop). O arquivo `web/_headers` liga as proteções do navegador no Netlify; não apague.

Telas prontas no banco: Login, Painel, Funis, Conversas e Configurações (perfil e senha, equipe, origens, motivos de perda, integrações, dados).
Próxima leva: Atividades, Gestor de metas, Prospecção, Disparos, Produtos, Scripts e Contatos.

O passo a passo completo está no documento "Conversas da Veka: como ligar o WhatsApp e o Instagram".

Segurança: verificação em duas etapas (aplicativo autenticador), registro de atividades, exclusão só por administradores, saída automática por inatividade, senha forte e proteções do navegador. Detalhes na etapa 6 do passo a passo.

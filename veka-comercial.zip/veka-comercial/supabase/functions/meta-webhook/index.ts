// Recebe as mensagens do WhatsApp e do Instagram que a Meta manda para cá.
// Publicar sem exigir login: supabase functions deploy meta-webhook --no-verify-jwt
// Arquivo único: dá para colar direto no editor de funções do Supabase.

import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";

export const VERSAO = Deno.env.get("META_API_VERSION") ?? "v26.0";

export const cors: Record<string, string> = {
  "Access-Control-Allow-Origin": Deno.env.get("ORIGEM_PERMITIDA") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}

// Cliente com a chave de serviço: só existe dentro do servidor, nunca na tela.
export function admin(): SupabaseClient {
  return createClient(Deno.env.get("SUPABASE_URL")!, (Deno.env.get("SB_SECRET_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"))!, {
    auth: { persistSession: false },
  });
}

export type Canal = "WhatsApp" | "Instagram";

export interface NovaMensagem {
  canal: Canal;
  contatoId: string;
  contaId?: string;
  nome?: string;
  usuario?: string;
  direcao: "entrada" | "saida";
  tipo: string;
  texto: string;
  metaId?: string;
  quando: Date;
  enviadoPor?: string;
}

// Acha ou cria a conversa, grava a mensagem (sem duplicar) e atualiza o resumo da conversa.
export async function registrar(db: SupabaseClient, m: NovaMensagem): Promise<string | null> {
  const { data: existente, error: e1 } = await db
    .from("conversas")
    .select("id, nome, usuario, nao_lidas, ultima_msg_em")
    .eq("canal", m.canal)
    .eq("contato_id", m.contatoId)
    .maybeSingle();
  if (e1) throw e1;

  let conversaId = existente?.id as string | undefined;
  if (!conversaId) {
    const { data: criada, error: e2 } = await db
      .from("conversas")
      .insert({ canal: m.canal, contato_id: m.contatoId, conta_id: m.contaId ?? null, nome: m.nome ?? null, usuario: m.usuario ?? null })
      .select("id")
      .single();
    if (e2) {
      // Duas mensagens chegando juntas podem criar a mesma conversa ao mesmo tempo.
      const { data: outra } = await db.from("conversas").select("id").eq("canal", m.canal).eq("contato_id", m.contatoId).single();
      conversaId = outra?.id;
    } else {
      conversaId = criada.id;
    }
  }
  if (!conversaId) return null;

  if (m.metaId) {
    const { data: jaTem } = await db.from("mensagens").select("id").eq("meta_id", m.metaId).maybeSingle();
    if (jaTem) return conversaId;
  }

  const { error: e3 } = await db.from("mensagens").insert({
    conversa_id: conversaId,
    direcao: m.direcao,
    tipo: m.tipo,
    texto: m.texto,
    meta_id: m.metaId ?? null,
    status: m.direcao === "entrada" ? "recebida" : "enviada",
    enviado_por: m.enviadoPor ?? null,
    criada_em: m.quando.toISOString(),
  });
  if (e3 && !String(e3.message).includes("duplicate")) throw e3;

  const resumo: Record<string, unknown> = {};
  const maisNova = !existente?.ultima_msg_em || new Date(existente.ultima_msg_em as string) <= m.quando;
  if (maisNova) {
    resumo.ultima_msg = (m.direcao === "saida" ? "Você: " : "") + m.texto;
    resumo.ultima_msg_em = m.quando.toISOString();
  }
  if (m.direcao === "entrada") {
    resumo.ultima_entrada_em = m.quando.toISOString();
    resumo.nao_lidas = ((existente?.nao_lidas as number) ?? 0) + 1;
    resumo.arquivada = false;
  }
  if (m.nome && !existente?.nome) resumo.nome = m.nome;
  if (m.usuario && !existente?.usuario) resumo.usuario = m.usuario;
  if (Object.keys(resumo).length) await db.from("conversas").update(resumo).eq("id", conversaId);
  return conversaId;
}

// ---------------------------------------------------------------
const enc = new TextEncoder();

async function assinaturaValida(corpo: string, cabecalho: string | null): Promise<boolean> {
  if (!cabecalho || !cabecalho.startsWith("sha256=")) return false;
  const recebida = cabecalho.slice(7).toLowerCase();
  // O WhatsApp e o Instagram podem usar apps (e chaves secretas) diferentes: aceita qualquer uma das duas.
  const segredos = [Deno.env.get("WA_APP_SECRET"), Deno.env.get("IG_APP_SECRET")].filter(Boolean) as string[];
  for (const segredo of segredos) {
    const chave = await crypto.subtle.importKey("raw", enc.encode(segredo), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const assinatura = await crypto.subtle.sign("HMAC", chave, enc.encode(corpo));
    const hex = Array.from(new Uint8Array(assinatura)).map((b) => b.toString(16).padStart(2, "0")).join("");
    if (hex.length === recebida.length) {
      let diferenca = 0;
      for (let i = 0; i < hex.length; i++) diferenca |= hex.charCodeAt(i) ^ recebida.charCodeAt(i);
      if (diferenca === 0) return true;
    }
  }
  return false;
}

// deno-lint-ignore no-explicit-any
function textoWhatsApp(msg: any): { tipo: string; texto: string } {
  switch (msg.type) {
    case "text": return { tipo: "texto", texto: msg.text?.body ?? "" };
    case "button": return { tipo: "texto", texto: msg.button?.text ?? "" };
    case "interactive": return { tipo: "texto", texto: msg.interactive?.button_reply?.title ?? msg.interactive?.list_reply?.title ?? "[resposta]" };
    case "image": return { tipo: "imagem", texto: msg.image?.caption ? "[foto] " + msg.image.caption : "[foto]" };
    case "video": return { tipo: "video", texto: msg.video?.caption ? "[vídeo] " + msg.video.caption : "[vídeo]" };
    case "audio": return { tipo: "audio", texto: "[áudio]" };
    case "document": return { tipo: "documento", texto: "[documento] " + (msg.document?.filename ?? "") };
    case "sticker": return { tipo: "figurinha", texto: "[figurinha]" };
    case "location": return { tipo: "local", texto: "[localização] " + (msg.location?.name ?? "") };
    case "reaction": return { tipo: "reacao", texto: "[reagiu com " + (msg.reaction?.emoji ?? "") + "]" };
    default: return { tipo: msg.type ?? "outro", texto: "[" + (msg.type ?? "mensagem") + "]" };
  }
}

// deno-lint-ignore no-explicit-any
async function processarWhatsApp(corpo: any) {
  const db = admin();
  for (const entry of corpo.entry ?? []) {
    for (const change of entry.changes ?? []) {
      if (change.field !== "messages") continue;
      const v = change.value ?? {};
      const contaId = v.metadata?.phone_number_id;
      const nomes: Record<string, string> = {};
      for (const c of v.contacts ?? []) nomes[c.wa_id] = c.profile?.name;
      for (const msg of v.messages ?? []) {
        const { tipo, texto } = textoWhatsApp(msg);
        await registrar(db, {
          canal: "WhatsApp", contatoId: msg.from, contaId, nome: nomes[msg.from], direcao: "entrada",
          tipo, texto, metaId: msg.id, quando: new Date(Number(msg.timestamp) * 1000),
        });
      }
      // Confirmações de entrega e leitura das mensagens enviadas pela Veka.
      for (const st of v.statuses ?? []) {
        const status = st.status === "read" ? "lida" : st.status === "delivered" ? "entregue" : st.status === "failed" ? "falhou" : "enviada";
        const erro = st.errors?.[0]?.title ?? st.errors?.[0]?.message ?? null;
        await db.from("mensagens").update({ status, erro }).eq("meta_id", st.id);
      }
    }
  }
}

async function perfilInstagram(igsid: string): Promise<{ nome?: string; usuario?: string }> {
  const token = Deno.env.get("IG_TOKEN");
  if (!token) return {};
  try {
    const r = await fetch(`https://graph.instagram.com/${VERSAO}/${igsid}?fields=name,username&access_token=${encodeURIComponent(token)}`);
    if (!r.ok) return {};
    const p = await r.json();
    return { nome: p.name || p.username, usuario: p.username ? "@" + p.username : undefined };
  } catch {
    return {};
  }
}

// deno-lint-ignore no-explicit-any
async function processarInstagram(corpo: any) {
  const db = admin();
  for (const entry of corpo.entry ?? []) {
    const contaId = String(entry.id ?? "");
    // A Meta manda em "messaging" no uso normal e em "changes" no botão de teste do painel.
    // deno-lint-ignore no-explicit-any
    const eventos: any[] = [...(entry.messaging ?? []), ...((entry.changes ?? []).filter((c: any) => c.field === "messages").map((c: any) => c.value))];
    for (const ev of eventos) {
      const m = ev.message;
      if (!m || m.is_deleted) continue;
      const eco = !!m.is_echo; // mensagem enviada pela própria conta da Veka (pelo app ou por este sistema)
      const contato = String(eco ? ev.recipient?.id : ev.sender?.id);
      if (!contato || contato === contaId) continue;
      const anexo = m.attachments?.[0]?.type;
      const texto = m.text ?? (anexo === "image" ? "[foto]" : anexo === "audio" ? "[áudio]" : anexo === "video" ? "[vídeo]" : anexo === "share" ? "[post compartilhado]" : anexo === "story_mention" ? "[mencionou a Veka no story]" : anexo ? "[" + anexo + "]" : "[mensagem]");
      const { data: conhecida } = await db.from("conversas").select("id").eq("canal", "Instagram").eq("contato_id", contato).maybeSingle();
      const perfil = conhecida ? {} : await perfilInstagram(contato);
      await registrar(db, {
        canal: "Instagram", contatoId: contato, contaId, nome: perfil.nome, usuario: perfil.usuario,
        direcao: eco ? "saida" : "entrada", tipo: m.text ? "texto" : (anexo ?? "outro"), texto,
        metaId: m.mid, quando: new Date(Number(ev.timestamp) || Date.now()), enviadoPor: eco ? "App do Instagram" : undefined,
      });
    }
  }
}

Deno.serve(async (req) => {
  const url = new URL(req.url);

  // 1. Verificação: a Meta chama uma vez quando você cadastra o webhook no painel.
  if (req.method === "GET") {
    const ok = url.searchParams.get("hub.mode") === "subscribe" && url.searchParams.get("hub.verify_token") === Deno.env.get("META_VERIFY_TOKEN");
    return ok ? new Response(url.searchParams.get("hub.challenge") ?? "", { status: 200 }) : new Response("token inválido", { status: 403 });
  }
  if (req.method !== "POST") return new Response("ok");

  // 2. Mensagens: confere se veio mesmo da Meta antes de gravar qualquer coisa.
  const corpo = await req.text();
  if (!(await assinaturaValida(corpo, req.headers.get("x-hub-signature-256")))) {
    return new Response("assinatura inválida", { status: 401 });
  }
  try {
    const dados = JSON.parse(corpo);
    if (dados.object === "whatsapp_business_account") await processarWhatsApp(dados);
    else if (dados.object === "instagram") await processarInstagram(dados);
  } catch (e) {
    // Responde 200 mesmo assim para a Meta não repetir o envio sem parar; o erro fica no log da função.
    console.error("Erro ao processar webhook:", e);
  }
  return new Response("ok", { status: 200 });
});

// Cria o acesso de uma pessoa nova da equipe (aba Configurações > Equipe).
// Só administradores podem usar. Publicar com Enforce JWT verification ligado.
import { createClient } from "npm:@supabase/supabase-js@2";

const cors: Record<string, string> = {
  "Access-Control-Allow-Origin": Deno.env.get("ORIGEM_PERMITIDA") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ erro: "Use POST." }, 405);

  const db = createClient(Deno.env.get("SUPABASE_URL")!, (Deno.env.get("SB_SECRET_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"))!, { auth: { persistSession: false } });
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  const { data: u } = token ? await db.auth.getUser(token) : { data: null };
  if (!u?.user) return json({ erro: "Faça login de novo." }, 401);
  const { data: eu } = await db.from("equipe").select("admin, ativo").eq("user_id", u.user.id).maybeSingle();
  if (!eu?.admin || !eu?.ativo) return json({ erro: "Só administradores convidam pessoas." }, 403);

  let b: { email?: string; nome?: string; papel?: string; senha?: string };
  try { b = await req.json(); } catch { return json({ erro: "Pedido inválido." }, 400); }
  const email = (b.email ?? "").trim().toLowerCase();
  const nome = (b.nome ?? "").trim();
  const senha = b.senha ?? "";
  if (!email.includes("@") || !nome) return json({ erro: "Preencha nome e e-mail." }, 400);
  if (senha.length < 10 || !/[a-zA-Z]/.test(senha) || !/\d/.test(senha)) return json({ erro: "A senha provisória precisa ter 10 ou mais caracteres, com letras e números." }, 400);

  const { data: criado, error } = await db.auth.admin.createUser({ email, password: senha, email_confirm: true, user_metadata: { nome } });
  if (error || !criado?.user) {
    const msg = String(error?.message ?? "");
    return json({ erro: msg.includes("already") ? "Esse e-mail já tem acesso. Se a pessoa saiu da equipe, reative na lista." : "Não foi possível criar o acesso: " + msg }, 400);
  }
  const { error: e2 } = await db.from("equipe").insert({ user_id: criado.user.id, nome, email, papel: b.papel || "SDR", admin: false, ativo: true });
  if (e2) return json({ erro: "O acesso foi criado, mas não entrou na equipe: " + e2.message }, 500);
  return json({ ok: true });
});

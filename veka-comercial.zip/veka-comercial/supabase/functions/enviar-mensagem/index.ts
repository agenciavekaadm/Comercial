// Envia uma resposta da tela de Conversas para o WhatsApp ou o Instagram.
// Só aceita quem está logado e cadastrado na tabela equipe.
// Arquivo único: dá para colar direto no editor de funções do Supabase.

import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";

export const VERSAO = Deno.env.get("META_API_VERSION") ?? "v26.0";

export const cors: Record<string, string> = {
  "Access-Control-Allow-Origin": Deno.env.get("ORIGEM_PERMITIDA") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}

// Cliente com a chave de serviço: só existe dentro do servidor, nunca na tela.
export function admin(): SupabaseClient {
  return createClient(Deno.env.get("SUPABASE_URL")!, (Deno.env.get("SB_SECRET_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"))!, {
    auth: { persistSession: false },
  });
}

export type Canal = "WhatsApp" | "Instagram";

export interface NovaMensagem {
  canal: Canal;
  contatoId: string;
  contaId?: string;
  nome?: string;
  usuario?: string;
  direcao: "entrada" | "saida";
  tipo: string;
  texto: string;
  metaId?: string;
  quando: Date;
  enviadoPor?: string;
}

// Acha ou cria a conversa, grava a mensagem (sem duplicar) e atualiza o resumo da conversa.
export async function registrar(db: SupabaseClient, m: NovaMensagem): Promise<string | null> {
  const { data: existente, error: e1 } = await db
    .from("conversas")
    .select("id, nome, usuario, nao_lidas, ultima_msg_em")
    .eq("canal", m.canal)
    .eq("contato_id", m.contatoId)
    .maybeSingle();
  if (e1) throw e1;

  let conversaId = existente?.id as string | undefined;
  if (!conversaId) {
    const { data: criada, error: e2 } = await db
      .from("conversas")
      .insert({ canal: m.canal, contato_id: m.contatoId, conta_id: m.contaId ?? null, nome: m.nome ?? null, usuario: m.usuario ?? null })
      .select("id")
      .single();
    if (e2) {
      // Duas mensagens chegando juntas podem criar a mesma conversa ao mesmo tempo.
      const { data: outra } = await db.from("conversas").select("id").eq("canal", m.canal).eq("contato_id", m.contatoId).single();
      conversaId = outra?.id;
    } else {
      conversaId = criada.id;
    }
  }
  if (!conversaId) return null;

  if (m.metaId) {
    const { data: jaTem } = await db.from("mensagens").select("id").eq("meta_id", m.metaId).maybeSingle();
    if (jaTem) return conversaId;
  }

  const { error: e3 } = await db.from("mensagens").insert({
    conversa_id: conversaId,
    direcao: m.direcao,
    tipo: m.tipo,
    texto: m.texto,
    meta_id: m.metaId ?? null,
    status: m.direcao === "entrada" ? "recebida" : "enviada",
    enviado_por: m.enviadoPor ?? null,
    criada_em: m.quando.toISOString(),
  });
  if (e3 && !String(e3.message).includes("duplicate")) throw e3;

  const resumo: Record<string, unknown> = {};
  const maisNova = !existente?.ultima_msg_em || new Date(existente.ultima_msg_em as string) <= m.quando;
  if (maisNova) {
    resumo.ultima_msg = (m.direcao === "saida" ? "Você: " : "") + m.texto;
    resumo.ultima_msg_em = m.quando.toISOString();
  }
  if (m.direcao === "entrada") {
    resumo.ultima_entrada_em = m.quando.toISOString();
    resumo.nao_lidas = ((existente?.nao_lidas as number) ?? 0) + 1;
    resumo.arquivada = false;
  }
  if (m.nome && !existente?.nome) resumo.nome = m.nome;
  if (m.usuario && !existente?.usuario) resumo.usuario = m.usuario;
  if (Object.keys(resumo).length) await db.from("conversas").update(resumo).eq("id", conversaId);
  return conversaId;
}

// ---------------------------------------------------------------
const JANELA_MS = 24 * 60 * 60 * 1000;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ erro: "Use POST." }, 405);

  // Quem está enviando?
  const auth = req.headers.get("Authorization") ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  const db = admin();
  const { data: u } = token ? await db.auth.getUser(token) : { data: null };
  if (!u?.user) return json({ erro: "Faça login de novo." }, 401);

  const { data: membro } = await db.from("equipe").select("nome").eq("user_id", u.user.id).maybeSingle();
  if (!membro) return json({ erro: "Seu usuário não está na equipe do comercial." }, 403);

  let corpo: { conversa_id?: string; texto?: string };
  try { corpo = await req.json(); } catch { return json({ erro: "Pedido inválido." }, 400); }
  const texto = (corpo.texto ?? "").trim();
  if (!corpo.conversa_id || !texto) return json({ erro: "Falta a conversa ou o texto." }, 400);

  const { data: conv } = await db.from("conversas").select("*").eq("id", corpo.conversa_id).maybeSingle();
  if (!conv) return json({ erro: "Conversa não encontrada." }, 404);

  // Regra da Meta: mensagem livre só até 24 horas depois da última mensagem do contato.
  const ultima = conv.ultima_entrada_em ? new Date(conv.ultima_entrada_em).getTime() : 0;
  if (!ultima || Date.now() - ultima > JANELA_MS) {
    return json({
      erro: conv.canal === "WhatsApp"
        ? "Passaram mais de 24 horas desde a última mensagem deste contato. No WhatsApp, agora só dá para mandar uma mensagem de modelo aprovada pela Meta."
        : "Passaram mais de 24 horas desde a última mensagem deste contato. O Instagram só libera resposta depois que ele escrever de novo.",
      foraDaJanela: true,
    }, 409);
  }

  let metaId: string | undefined;
  let detalhe = "";
  try {
    if (conv.canal === "WhatsApp") {
      const numeroId = conv.conta_id || Deno.env.get("WA_PHONE_NUMBER_ID");
      const r = await fetch(`https://graph.facebook.com/${VERSAO}/${numeroId}/messages`, {
        method: "POST",
        headers: { Authorization: `Bearer ${Deno.env.get("WA_TOKEN")}`, "Content-Type": "application/json" },
        body: JSON.stringify({ messaging_product: "whatsapp", recipient_type: "individual", to: conv.contato_id, type: "text", text: { preview_url: true, body: texto } }),
      });
      const resp = await r.json();
      if (!r.ok) detalhe = resp?.error?.error_user_msg ?? resp?.error?.message ?? "erro " + r.status;
      metaId = resp?.messages?.[0]?.id;
    } else {
      const r = await fetch(`https://graph.instagram.com/${VERSAO}/me/messages`, {
        method: "POST",
        headers: { Authorization: `Bearer ${Deno.env.get("IG_TOKEN")}`, "Content-Type": "application/json" },
        body: JSON.stringify({ recipient: { id: conv.contato_id }, message: { text: texto } }),
      });
      const resp = await r.json();
      if (!r.ok) detalhe = resp?.error?.error_user_msg ?? resp?.error?.message ?? "erro " + r.status;
      metaId = resp?.message_id;
    }
  } catch (e) {
    detalhe = String(e);
  }

  if (detalhe || !metaId) {
    console.error("Falha no envio:", detalhe);
    return json({ erro: "A Meta recusou o envio: " + (detalhe || "sem resposta") }, 502);
  }

  await registrar(db, {
    canal: conv.canal, contatoId: conv.contato_id, direcao: "saida", tipo: "texto", texto,
    metaId, quando: new Date(), enviadoPor: membro.nome,
  });
  await db.from("conversas").update({ nao_lidas: 0, responsavel: conv.responsavel ?? membro.nome }).eq("id", conv.id);
  return json({ ok: true, metaId });
});

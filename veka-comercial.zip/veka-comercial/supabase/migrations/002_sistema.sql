-- Veka Comercial · sistema completo (rodar depois do 001_conversas.sql)
-- SQL Editor > New query > colar > Run.

-- 1. Perfil de cada pessoa da equipe (usado na aba Configurações > Perfil e senha).
alter table public.equipe add column if not exists email text;
alter table public.equipe add column if not exists cargo text;
alter table public.equipe add column if not exists telefone text;
alter table public.equipe add column if not exists foto_url text;
alter table public.equipe add column if not exists admin boolean not null default false;
alter table public.equipe add column if not exists ativo boolean not null default true;

create or replace function public.eh_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.equipe where user_id = auth.uid() and admin and ativo);
$$;

-- Quem está desativado perde o acesso na hora.
create or replace function public.eh_da_equipe() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.equipe where user_id = auth.uid() and ativo);
$$;

drop policy if exists "cada um edita o proprio perfil" on public.equipe;
create policy "cada um edita o proprio perfil" on public.equipe for update to authenticated
  using (user_id = auth.uid() or public.eh_admin())
  with check (user_id = auth.uid() or public.eh_admin());

-- Ninguém se promove sozinho: só admin muda admin, ativo e papel.
create or replace function public.protege_equipe() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_admin() and (new.admin is distinct from old.admin or new.ativo is distinct from old.ativo or new.papel is distinct from old.papel) then
    raise exception 'Só quem é administrador muda papel, acesso ou administração.';
  end if;
  return new;
end $$;
drop trigger if exists protege_equipe on public.equipe;
create trigger protege_equipe before update on public.equipe for each row execute function public.protege_equipe();

-- 2. Dados do comercial: leads, tarefas, vendas, metas, produtos, scripts, cadências, automações,
--    segmentos, campanhas, funis e configurações. Um registro por item, agrupado por coleção.
create table if not exists public.itens (
  colecao text not null,
  id text not null,
  dados jsonb not null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  atualizado_por uuid default auth.uid(),
  primary key (colecao, id)
);
create index if not exists itens_colecao_idx on public.itens (colecao);

create or replace function public.carimba_item() returns trigger
language plpgsql as $$
begin
  new.atualizado_em := now();
  new.atualizado_por := auth.uid();
  return new;
end $$;
drop trigger if exists carimba_item on public.itens;
create trigger carimba_item before insert or update on public.itens for each row execute function public.carimba_item();

alter table public.itens enable row level security;
drop policy if exists "equipe le itens" on public.itens;
create policy "equipe le itens" on public.itens for select to authenticated using (public.eh_da_equipe());
drop policy if exists "equipe cria itens" on public.itens;
create policy "equipe cria itens" on public.itens for insert to authenticated with check (public.eh_da_equipe());
drop policy if exists "equipe altera itens" on public.itens;
create policy "equipe altera itens" on public.itens for update to authenticated using (public.eh_da_equipe()) with check (public.eh_da_equipe());
drop policy if exists "equipe apaga itens" on public.itens;
create policy "equipe apaga itens" on public.itens for delete to authenticated using (public.eh_da_equipe());

do $$
begin
  begin alter publication supabase_realtime add table public.itens; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.equipe; exception when duplicate_object then null; end;
end $$;

-- 3. Fotos de perfil.
insert into storage.buckets (id, name, public) values ('avatares', 'avatares', true)
on conflict (id) do nothing;

drop policy if exists "equipe sobe foto" on storage.objects;
create policy "equipe sobe foto" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatares' and public.eh_da_equipe());
drop policy if exists "equipe troca foto" on storage.objects;
create policy "equipe troca foto" on storage.objects for update to authenticated
  using (bucket_id = 'avatares' and public.eh_da_equipe());

-- 4. A Ana como administradora (troque o e-mail). Admin convida e desativa pessoas na aba Equipe.
-- insert into public.equipe (user_id, nome, papel, admin, email)
-- select id, 'Ana', 'Sócia', true, email from auth.users where email = 'EMAIL_DA_ANA'
-- on conflict (user_id) do update set admin = true;

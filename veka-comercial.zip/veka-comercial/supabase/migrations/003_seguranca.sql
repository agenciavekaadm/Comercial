-- Veka Comercial · camada de segurança (rodar depois do 002_sistema.sql)

-- 1. Verificação em duas etapas: quem ativou o código do celular só acessa os dados
--    depois de digitar o código. Vale direto no banco, não só na tela.
do $$
declare t text;
begin
  foreach t in array array['itens', 'conversas', 'mensagens', 'equipe'] loop
    execute format('drop policy if exists "exige duas etapas" on public.%I', t);
    execute format($p$
      create policy "exige duas etapas" on public.%I as restrictive for all to authenticated
      using (array[(select auth.jwt()->>'aal')] <@ (
        select case when count(id) > 0 then array['aal2'] else array['aal1', 'aal2'] end
        from auth.mfa_factors where user_id = (select auth.uid()) and status = 'verified'))
      with check (array[(select auth.jwt()->>'aal')] <@ (
        select case when count(id) > 0 then array['aal2'] else array['aal1', 'aal2'] end
        from auth.mfa_factors where user_id = (select auth.uid()) and status = 'verified'))
    $p$, t);
  end loop;
end $$;

-- 2. Apagar dados: só administradores. O resto da equipe cria e altera.
drop policy if exists "equipe apaga itens" on public.itens;
drop policy if exists "admin apaga itens" on public.itens;
create policy "admin apaga itens" on public.itens for delete to authenticated using (public.eh_admin());

-- 3. Registro de atividades: toda criação, alteração e exclusão fica anotada com quem e quando.
create table if not exists public.auditoria (
  id bigint generated always as identity primary key,
  quando timestamptz not null default now(),
  user_id uuid,
  quem text,
  tabela text not null,
  colecao text,
  item_id text,
  acao text not null,
  resumo text
);
create index if not exists auditoria_quando_idx on public.auditoria (quando desc);
alter table public.auditoria enable row level security;
drop policy if exists "admin le auditoria" on public.auditoria;
create policy "admin le auditoria" on public.auditoria for select to authenticated using (public.eh_admin());
-- Ninguém escreve, altera ou apaga o registro pela tela: só o banco, pelos gatilhos abaixo.

create or replace function public.registra_auditoria() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  linha jsonb := to_jsonb(coalesce(new, old));
  antes jsonb := case when tg_op = 'UPDATE' then to_jsonb(old) else null end;
  nome text;
  res text;
begin
  select e.nome into nome from public.equipe e where e.user_id = auth.uid();
  if tg_table_name = 'itens' then
    res := coalesce(linha->'dados'->>'name', linha->'dados'->>'title', linha->'dados'->>'cliente', linha->>'id');
    if tg_op = 'UPDATE' and (old.dados->>'stage') is distinct from (new.dados->>'stage') then
      res := res || ': ' || coalesce(old.dados->>'stage', '') || ' → ' || coalesce(new.dados->>'stage', '');
    end if;
    insert into public.auditoria (user_id, quem, tabela, colecao, item_id, acao, resumo)
    values (auth.uid(), nome, 'itens', linha->>'colecao', linha->>'id', lower(tg_op), res);
  elsif tg_table_name = 'equipe' then
    res := linha->>'nome';
    if tg_op = 'UPDATE' then
      if (antes->>'ativo') is distinct from (linha->>'ativo') then res := res || (case when (linha->>'ativo')::boolean then ': acesso devolvido' else ': acesso retirado' end); end if;
      if (antes->>'admin') is distinct from (linha->>'admin') then res := res || (case when (linha->>'admin')::boolean then ': virou admin' else ': deixou de ser admin' end); end if;
      if (antes->>'papel') is distinct from (linha->>'papel') then res := res || ': papel ' || coalesce(linha->>'papel', ''); end if;
    end if;
    insert into public.auditoria (user_id, quem, tabela, item_id, acao, resumo)
    values (auth.uid(), nome, 'equipe', linha->>'user_id', lower(tg_op), res);
  end if;
  return coalesce(new, old);
end $$;

drop trigger if exists audita_itens on public.itens;
create trigger audita_itens after insert or update or delete on public.itens for each row execute function public.registra_auditoria();
drop trigger if exists audita_equipe on public.equipe;
create trigger audita_equipe after insert or update or delete on public.equipe for each row execute function public.registra_auditoria();

-- Veka Comercial · Conversas de WhatsApp e Instagram
-- Rode este arquivo uma vez no Supabase: SQL Editor > New query > colar > Run.

create extension if not exists pgcrypto;

-- Quem da equipe pode usar a caixa de entrada (Carol e Victor).
create table if not exists public.equipe (
  user_id uuid primary key references auth.users (id) on delete cascade,
  nome text not null,
  papel text not null default 'SDR',
  criado_em timestamptz not null default now()
);

-- Uma conversa por contato e canal.
create table if not exists public.conversas (
  id uuid primary key default gen_random_uuid(),
  canal text not null check (canal in ('WhatsApp', 'Instagram')),
  contato_id text not null,            -- telefone no WhatsApp (só números) ou IGSID no Instagram
  conta_id text,                       -- phone_number_id do WhatsApp ou id da conta do Instagram da Veka
  nome text,
  usuario text,                        -- @ do Instagram, quando houver
  arquivada boolean not null default false,
  nao_lidas integer not null default 0,
  responsavel text,                    -- Carol ou Victor
  ultima_msg text,
  ultima_msg_em timestamptz,
  ultima_entrada_em timestamptz,       -- usada para a janela de 24 horas
  criada_em timestamptz not null default now(),
  unique (canal, contato_id)
);

create table if not exists public.mensagens (
  id uuid primary key default gen_random_uuid(),
  conversa_id uuid not null references public.conversas (id) on delete cascade,
  direcao text not null check (direcao in ('entrada', 'saida')),
  tipo text not null default 'texto',
  texto text,
  meta_id text unique,                 -- id da mensagem na Meta, evita duplicadas
  status text not null default 'recebida',
  enviado_por text,
  erro text,
  criada_em timestamptz not null default now()
);

create index if not exists mensagens_conversa_idx on public.mensagens (conversa_id, criada_em);
create index if not exists conversas_ordem_idx on public.conversas (arquivada, ultima_msg_em desc);

-- Segurança: só quem está na tabela equipe lê e mexe nas conversas.
-- O servidor (funções) usa a chave de serviço e passa por cima destas regras.
alter table public.equipe enable row level security;
alter table public.conversas enable row level security;
alter table public.mensagens enable row level security;

create or replace function public.eh_da_equipe() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.equipe where user_id = auth.uid());
$$;

drop policy if exists "equipe le equipe" on public.equipe;
create policy "equipe le equipe" on public.equipe for select to authenticated using (public.eh_da_equipe());

drop policy if exists "equipe le conversas" on public.conversas;
create policy "equipe le conversas" on public.conversas for select to authenticated using (public.eh_da_equipe());
drop policy if exists "equipe altera conversas" on public.conversas;
create policy "equipe altera conversas" on public.conversas for update to authenticated using (public.eh_da_equipe()) with check (public.eh_da_equipe());

drop policy if exists "equipe le mensagens" on public.mensagens;
create policy "equipe le mensagens" on public.mensagens for select to authenticated using (public.eh_da_equipe());

-- Tempo real: a tela recebe mensagens novas sem recarregar.
do $$
begin
  begin alter publication supabase_realtime add table public.conversas; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.mensagens; exception when duplicate_object then null; end;
end $$;
